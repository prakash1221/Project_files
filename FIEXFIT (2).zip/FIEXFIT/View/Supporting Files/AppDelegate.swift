//
//  AppDelegate.swift
//  FIEXFIT
//
//  Created by SAIL on 20/09/23.
//

import UIKit
import IQKeyboardManagerSwift
import SDWebImage

@main
class AppDelegate: UIResponder, UIApplicationDelegate {



    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        let manager = IQKeyboardManager.shared
        manager.enable = true
        manager.enableAutoToolbar = false
        manager.shouldShowToolbarPlaceholder = false
        manager.shouldPlayInputClicks = false
        manager.shouldResignOnTouchOutside = true
        return true
    }

    // MARK: UISceneSession Lifecycle

    func application(_ application: UIApplication, configurationForConnecting connectingSceneSession: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        
        return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
    }

    func application(_ application: UIApplication, didDiscardSceneSessions sceneSessions: Set<UISceneSession>) {
        
    }


}

