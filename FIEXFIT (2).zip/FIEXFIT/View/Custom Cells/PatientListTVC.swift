//
//  PatientListTVC.swift
//  FIEXFIT
//
//  Created by SAIL on 24/10/23.
//

import UIKit

class PatientListTVC: UITableViewCell {
    
    
    @IBOutlet weak var mainView: UIView!
   
    @IBOutlet weak var numberLabel: UILabel!
    @IBOutlet weak var patientImg: UIImageView!
    @IBOutlet weak var patientNameLabel: UILabel!
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        
        
    }
    
    
    override func layoutSubviews() {
      super.layoutSubviews()
    
     let margin = UIEdgeInsets(top: 5, left: 5, bottom: 5, right: 5)
      contentView.frame = contentView.frame.inset(by: margin)
      contentView.layer.cornerRadius = 10
    
    }
    
}
