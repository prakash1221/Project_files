//
//  feedback_question.swift
//  FIEXFIT
//
//  Created by SAIL on 20/12/23.
//

import UIKit

class feedback_question: UIViewController {

    
    @IBOutlet var qOneButtons: [UIButton]!
    @IBOutlet var qTwoButtons: [UIButton]!
    @IBOutlet weak var nobutton: UIButton!
    @IBOutlet weak var yesbutton: UIButton!
    
    
    var exerciseCompletion = ""
    var feedbackOption = ""
    var painScale = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("feedbackOption",feedbackOption)
        setupButtonActions(for: qOneButtons)
        setupButtoActions(for: qTwoButtons)
        setupYesNoButtons()
    }
    func setupButtonActions(for buttons: [UIButton]) {
        for button in buttons {
            guard let buttonTitle = button.currentTitle else { continue }

            if painScale == buttonTitle {
                button.setImage(UIImage(systemName: "checkmark.circle.fill")?.withTintColor(.orange), for: .normal)
            } else {
                button.setImage(UIImage(systemName: ""), for: .normal)
                button.tintColor = .systemBlue // Change the default color as needed
            }
           
        }
    }
    func setupButtoActions(for buttons: [UIButton]) {
        for button in buttons {
            guard let buttonTitle = button.currentTitle else { continue }
            print("buttonTitle",buttonTitle)
            if feedbackOption == buttonTitle {
                button.backgroundColor = .systemGreen
            }
        }
    }
    func setupYesNoButtons() {
            if exerciseCompletion == "Yes" || exerciseCompletion == "yes"  {
                yesbutton.setImage(UIImage(systemName: "checkmark.circle.fill")?.withTintColor(.orange), for: .normal)
//                yesbutton.backgroundColor = .systemGreen
            } else if exerciseCompletion == "No" || exerciseCompletion == "no" {
//                nobutton.backgroundColor = .systemRed
                nobutton.setImage(UIImage(systemName: "checkmark.circle.fill")?.withTintColor(.orange), for: .normal)
            }
        }
    
    @IBAction func backTap(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func doneTap(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "Doctors_HomePG") as! Doctors_HomePG
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
