//
//  CandidateHomePerfCVC.swift
//  FIEXFIT
//
//  Created by Saranya Ravi on 10/11/23.
//

import UIKit
import Charts

class CandidateHomePerfCVC: UICollectionViewCell {
    @IBOutlet weak var graphView: PieChartView!
    var patientId = UserDefaultsManager.shared.getUserId() ?? ""
    var patientSessions : Double = 0
    var patientPendingSessions : Double = 0
    override func awakeFromNib() {
        super.awakeFromNib()
        getApi()
    }
    func getApi() {
        
        let apiURL = APIList().urlString(url:.patientGraphApi) + patientId
        APIHandler().getAPIValues(type: PatientGraphModel.self, apiUrl: apiURL, method: "GET") {  result in
            switch result {
            case .success(let data):
                DispatchQueue.main.async { [self] in
                    if data.status == true{
                        patientSessions = data.data.sessions
                        patientPendingSessions = data.data.pendingSession
                        print("patientSessions : \(patientSessions)")
                        print("patientPendingSessions : \(patientPendingSessions)")
                        setChart(dataPoints: ["Completed","Pending"], values: [patientSessions,patientPendingSessions], chart: graphView)                     }
                    else if data.status == false{
                        print("error")
                    }
                    
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    
                    
                }
            }
        }
    }
    func setChart(dataPoints: [String], values: [Double], chart: PieChartView) {
        var dataEntries: [ChartDataEntry] = []
        for i in 0..<dataPoints.count {
            let dataEntry = PieChartDataEntry(value: values[i], label: dataPoints[i])
            dataEntries.append(dataEntry)
        }
        let pieChartDataSet = PieChartDataSet(entries: dataEntries, label: "")
        let colors = [UIColor(hex: 0x665CDF), UIColor(hex: 0x3486D1)]
        pieChartDataSet.colors = colors
        let pieChartData = PieChartData(dataSet: pieChartDataSet)
        chart.data = pieChartData
    }
}
