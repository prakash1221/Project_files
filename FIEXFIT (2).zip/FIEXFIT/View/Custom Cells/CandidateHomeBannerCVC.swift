//
//  CandidateHomeBannerCVC.swift
//  FIEXFIT
//
//  Created by Saranya Ravi on 10/11/23.
//

import UIKit
//import FSPagerView
struct BannerImage {
    var bImage : UIImage?
}
class CandidateHomeBannerCVC: UICollectionViewCell, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    
    @IBOutlet weak var bannerCollection: UICollectionView!
    
    var timer: Timer?
    
    var Bannerlists : [BannerImage] = []
    override func awakeFromNib() {
        super.awakeFromNib()
        
        let flowLayout = UICollectionViewFlowLayout()
                flowLayout.minimumInteritemSpacing = 10
                flowLayout.minimumLineSpacing = 10
                flowLayout.scrollDirection = .horizontal
        bannerCollection.collectionViewLayout = flowLayout
        
        Bannerlists.append(BannerImage.init(bImage: UIImage(named: "Banner1")))
        Bannerlists.append(BannerImage.init(bImage: UIImage(named: "Banner1")))
        Bannerlists.append(BannerImage.init(bImage: UIImage(named: "Banner1")))
        bannerCollection.register(UINib(nibName: "CHomeInnerBannerCVC", bundle: nil), forCellWithReuseIdentifier: "CHomeInnerBannerCVC")
        bannerCollection.dataSource = self
        bannerCollection.delegate = self
        bannerCollection.reloadData()
        
        
        
        


        

        timer = Timer.scheduledTimer(timeInterval: 2.0, target: self, selector: #selector(scrollToNextItem), userInfo: nil, repeats: true)

      


    }
    
    
    deinit {
          timer?.invalidate()
      }

      @objc func scrollToNextItem() {
      
          guard let visibleIndexPath = bannerCollection.indexPathsForVisibleItems.first else {
              return
          }

          let nextIndexPath: IndexPath
          if visibleIndexPath.item + 1 < 3 {
              nextIndexPath = IndexPath(item: visibleIndexPath.item + 1, section: visibleIndexPath.section)
          } else {
             
              timer?.invalidate()
              return
          }
          bannerCollection.scrollToItem(at: nextIndexPath, at: .centeredHorizontally, animated: true)
      }
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 3
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier:"CHomeInnerBannerCVC", for: indexPath) as! CHomeInnerBannerCVC
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
            return CGSize(width: collectionView.frame.width, height: 200.0)
        }

   
    
//    @IBOutlet weak var pagerView: FSPagerView! {
//        didSet {
//            self.pagerView.register(FSPagerViewCell.self,forCellWithReuseIdentifier: "cell")
//            
//        }
//    }
   
//        pagerView.layer.cornerRadius = 10
//        pagerView.layer.masksToBounds = true
//        self.pagerView.automaticSlidingInterval = 2.0
      // pagerView.isInfinite = true
//        self.pagerView.delegate = self
//        self.pagerView.dataSource = self
//        self.pagerView.reloadData()
//       
       
    
//    func numberOfItems(in pagerView: FSPagerView) -> Int {
//        return Bannerlists.count
//    }
    
//    func pagerView(_ pagerView: FSPagerView, cellForItemAt index: Int) -> FSPagerViewCell {
//        let cell = pagerView.dequeueReusableCell(withReuseIdentifier: "cell", at: index)
//        let dict = Bannerlists[index]
//        cell.imageView?.clipsToBounds = true
//        cell.isUserInteractionEnabled = false
//        cell.imageView?.sd_setImage(with: URL.init(string: (dict.bImage ?? "" as NSObject) as! String))
//        return cell
//    }
    
}

