//
//  MenuTVC.swift
//  FIEXFIT
//
//  Created by Saranya Ravi on 07/11/23.
//

import UIKit

class MenuTVC: UITableViewCell {

    @IBOutlet weak var sidemenuImage: UIImageView!
    @IBOutlet weak var sidemenuName: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
