//
//  CandidateHomeCategoriesCVC.swift
//  FIEXFIT
//
//  Created by Saranya Ravi on 10/11/23.
//

import UIKit

class CandidateHomeCategoriesCVC: UICollectionViewCell {

    @IBOutlet weak var dailyexerciseBtn: UIButton!
    
    
    @IBOutlet weak var educationalBtn: UIButton!
    
    
    @IBOutlet weak var progressTrackBtn: UIButton!
    
    @IBOutlet weak var chatBtn: UIButton!
    
    
   // var tapLogin:(() ->())?
    var tapExercise : (() -> ())?
    var tapEducation : (() -> ())?
    var tapProgress : (() -> ())?
    var tapChat : (() -> ())?
    override func awakeFromNib() {
        super.awakeFromNib()
        dailyexerciseBtn.layer.cornerRadius = 5
        educationalBtn.layer.cornerRadius = 5
        progressTrackBtn.layer.cornerRadius = 5
        chatBtn.layer.cornerRadius = 5
        
        // Initialization code
    }
    
    @IBAction func onExercise(_ sender: Any) {
       tapExercise?()
    }
    @IBAction func onEducation(_ sender: Any) {
        tapEducation?()
    }
    @IBAction func onProgress(_ sender: Any) {
        tapProgress?()
    }
    @IBAction func onChat(_ sender: Any) {
       tapChat?()
    }
    
}
