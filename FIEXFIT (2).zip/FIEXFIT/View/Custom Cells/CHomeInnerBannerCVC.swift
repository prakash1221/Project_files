//
//  CHomeInnerBannerCVC.swift
//  FIEXFIT
//
//  Created by Saranya Ravi on 18/11/23.
//

import UIKit

class CHomeInnerBannerCVC: UICollectionViewCell {

    @IBOutlet weak var bannerImg: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
