//
//  DailyExerciseListTVC.swift
//  FIEXFIT
//
//  Created by Saranya Ravi on 09/11/23.
//

import UIKit

class DailyExerciseListTVC: UITableViewCell {

    @IBOutlet weak var dailySessionName: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
