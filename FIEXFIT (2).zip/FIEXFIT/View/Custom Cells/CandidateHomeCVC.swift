//
//  CandidateHomeCVC.swift
//  FIEXFIT
//
//  Created by Saranya Ravi on 10/11/23.
//

import UIKit

class CandidateHomeCVC: UICollectionViewCell {
    

}
