//
//  LoginModel.swift
//  FIEXFIT
//
//  Created by SAIL on 26/12/23.
//

import Foundation

struct DoctorLoginModel: Codable {
    let status: Bool
    let message: String
    let data: [DoctorLoginDetail]
}
struct DoctorLoginDetail: Codable {
    let username, doctorID: String
    let name, age, gender: String

    enum CodingKeys: String, CodingKey {
     
        case username
        case doctorID = "doctor_id"
        case name, age, gender
    }
}



struct PatientLoginModel: Codable {
    let status: Bool
    let message: String
    let data: [Datum]
}

// MARK: - Datum
struct Datum: Codable {
    let patID, userID, password, patientName: String
    let dob, age, gender, fmsScore: String
    let mobileNumber, connectionType: String

    enum CodingKeys: String, CodingKey {
        case patID = "pat_id"
        case userID = "user_id"
        case password
        case patientName = "patient_name"
        case dob, age, gender
        case fmsScore = "FMS_Score"
        case mobileNumber = "mobile_number"
        case connectionType = "connection_type"
    }
}


struct DoctorProfile: Codable {
    let success: Bool
    let data: DataClass
    let message: String
}

// MARK: - DataClass
struct DataClass: Codable {
    let username, doctorID, password, name: String
    let age, gender: String

    enum CodingKeys: String, CodingKey {
        case username
        case doctorID = "doctor_id"
        case password, name, age, gender
    }
}
