//
//  PatientProfileModel.swift
//  FIEXFIT
//
//  Created by SAIL on 10/01/24.
//

import Foundation

struct PatientProfileModel: Codable {
    let status: Bool
    let patientProfile: PatientProfileData
    let message: String

    enum CodingKeys: String, CodingKey {
        case status
        case patientProfile = "patient_profile"
        case message
    }
}

// MARK: - PatientProfile
struct PatientProfileData: Codable {
    let userID, patientName, dob, gender: String
    let fmsScore, mobileNumber,photo, connectionType: String
    
    enum CodingKeys: String, CodingKey {
        case userID = "user_id"
        case patientName = "patient_name"
        case dob, gender,photo
        case fmsScore = "FMS_Score"
        case mobileNumber = "mobile_number"
        case connectionType = "connection_type"
    }
}
