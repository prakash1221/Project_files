//
//  FetchResponseModel.swift
//  FIEXFIT
//
//  Created by SAIL on 19/02/24.
//

import Foundation
struct FetchResponseModel: Codable {
    let status: Bool
    let message: String
    let data: FetchResponseData
}

// MARK: - DataClass
struct FetchResponseData: Codable {
    let id, weekNumber, sessionNumber, userID: String
    let responseID, exerciseCompletion, painScale, feedbackOption: String
    let connectionType, dateAndTime: String
    let stability, mobility, proprioception: [String]
    let timestamp: String

    enum CodingKeys: String, CodingKey {
        case id = "Id"
        case weekNumber = "week_number"
        case sessionNumber = "session_number"
        case userID = "user_id"
        case responseID = "response_id"
        case exerciseCompletion = "exercise_completion"
        case painScale = "pain_scale"
        case feedbackOption = "feedback_option"
        case connectionType = "connection_type"
        case dateAndTime = "date_and_time"
        case stability, mobility, proprioception, timestamp
    }
}
