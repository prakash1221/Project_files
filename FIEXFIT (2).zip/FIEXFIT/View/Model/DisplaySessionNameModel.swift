//
//  DisplaySessionNameModel.swift
//  FIEXFIT
//
//  Created by SAIL on 07/02/24.
//

import Foundation


// MARK: - Welcome
import Foundation

// MARK: - Welcome
struct DisplaySessionNameModel: Codable {
    let status: Bool
    let message: String
    let data: [DisplaySessionNameData]
}

// MARK: - Datum
struct DisplaySessionNameData: Codable {
    let videoTitle, videoPath: String

    enum CodingKeys: String, CodingKey {
        case videoTitle = "video_title"
        case videoPath = "video_path"
    }
}

