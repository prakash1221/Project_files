//
//  PatientRecodedVideoModel.swift
//  FIEXFIT
//
//  Created by SAIL on 11/03/24.
//

import Foundation

struct PatientRecodedVideoModel: Codable {
    let status: Bool
    let message: String
    let data: [PatientRecodedVideoData]
}

// MARK: - Datum
struct PatientRecodedVideoData: Codable {
    let userID, week, videoTitle, recordedPatientVideo: String

    enum CodingKeys: String, CodingKey {
        case userID = "user_id"
        case week
        case videoTitle = "video_title"
        case recordedPatientVideo = "recorded_patient_video"
    }
}
