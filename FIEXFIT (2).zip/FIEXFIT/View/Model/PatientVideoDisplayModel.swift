//
//  PatientVideoDisplayModel.swift
//  FIEXFIT
//
//  Created by SAIL on 10/02/24.
//


import Foundation

// MARK: - Welcome
struct PatientVideoDisplayModel: Codable {
    let status: Bool
    let message: String
    let data: [PatientVideoDisplayData]
}

// MARK: - Datum
struct PatientVideoDisplayData: Codable {
    let week, category: String
    let selectedTitles, selectedPath: [String]
    let userID: String

    enum CodingKeys: String, CodingKey {
        case week, category
        case selectedTitles = "selected_titles"
        case selectedPath = "selected_path"
        case userID = "user_id"
    }
}


struct PatientVideoListModel: Codable {
    let status: Bool
    let message: String
    let data: [PatientVideoListData]
}

// MARK: - Datum
struct PatientVideoListData: Codable {
    let category: String
    let selectedTitles: [String]
    let userID: String

    enum CodingKeys: String, CodingKey {
        case category
        case selectedTitles = "selected_titles"
        case userID = "user_id"
    }
}

struct DisplayVideoListModel: Codable {
    let status: Bool
    let message: String
    let data: [String]
}

//struct PatientVideoListModel: Codable {
//    let status: Bool
//    let message: String
//    let data: [PatientVideoListData]
//}
//
//// MARK: - Datum
//struct PatientVideoListData: Codable {
//    let week, category: String
//    let selectedTitles: [String]
//    let userID: String
//
//    enum CodingKeys: String, CodingKey {
//        case week, category
//        case selectedTitles = "selected_titles"
//        case userID = "user_id"
//    }
//}
