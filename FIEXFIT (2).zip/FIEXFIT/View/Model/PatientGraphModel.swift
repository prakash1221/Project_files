//
//  PatientGraphModel.swift
//  FIEXFIT
//
//  Created by SAIL on 12/02/24.
//

import Foundation
// MARK: - Welcome
struct PatientGraphModel: Codable {
    let status: Bool
    let message: String
    let data: PatientGraphData
}

// MARK: - DataClass
struct PatientGraphData: Codable {
    let userID: String
    let sessions, pendingSession: Double

    enum CodingKeys: String, CodingKey {
        case userID = "user_id"
        case sessions
        case pendingSession = "pending_session"
    }
}
