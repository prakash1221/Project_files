//
//  ExerciseVideo.swift
//  FIEXFIT
//
//  Created by Saranya Ravi on 25/11/23.
//

import UIKit

struct ExerciseVideo: Codable {
    let id: Int
    let title: String
    let videoURL: URL
}

