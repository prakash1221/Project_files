//
//  AddPatientModel.swift
//  FIEXFIT
//
//  Created by SAIL on 29/12/23.
//

import Foundation

struct AddCandidateModel: Codable {
    let status: Bool
    let message: String
}

