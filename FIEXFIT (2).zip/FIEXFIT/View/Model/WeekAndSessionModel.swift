//
//  WeekAndSessionModel.swift
//  FIEXFIT
//
//  Created by SAIL on 06/02/24.
//

import Foundation

// MARK: - Welcome
struct WeekAndSessionModel: Codable {
    let status: Bool
    let message: String
    let data: [WeekAndSessionData]
}

// MARK: - Datum
struct WeekAndSessionData: Codable {
    let weekNumber: Int
    let days: [Day]

    enum CodingKeys: String, CodingKey {
        case weekNumber = "week_number"
        case days
    }
}

// MARK: - Day
struct Day: Codable {
    let sessionNumber: Int
    let dateAndTime: String

    enum CodingKeys: String, CodingKey {
        case sessionNumber = "session_number"
        case dateAndTime = "date_and_time"
    }
}


