//
//  PatientListModel.swift
//  FIEXFIT
//
//  Created by SAIL on 30/12/23.
//

import Foundation
struct PatientListModel: Codable {
    let status: Bool
    let message: String
    let data: [PatientListData]
}

// MARK: - Datum
struct PatientListData: Codable {
    let patientID, name, mobileNumber, dob: String
    let fmsScore, gender, connectionType: String
    let photo: String?

    enum CodingKeys: String, CodingKey {
        case patientID = "patient_id"
        case name
        case mobileNumber = "mobile_number"
        case dob
        case fmsScore = "FMS_Score"
        case gender
        case connectionType = "connection_type"
        case photo
    }
}

