//
//  GraphModel.swift
//  FIEXFIT
//
//  Created by SAIL on 10/02/24.
//

import Foundation
// MARK: - Welcome
struct GraphModel: Codable {
    let status: Bool
    let message: String
    let data: [GraphData]
}

// MARK: - Datum
struct GraphData: Codable {
    let completed, pending: String
}
