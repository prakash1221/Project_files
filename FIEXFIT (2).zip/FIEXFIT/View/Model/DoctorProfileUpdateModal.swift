//
//  DoctorProfileUpdateModal.swift
//  FIEXFIT
//
//  Created by SAIL on 05/02/24.
//

import Foundation
struct DoctorProfileUpdateModal: Codable {
    let success: Bool
    let message: String
}
