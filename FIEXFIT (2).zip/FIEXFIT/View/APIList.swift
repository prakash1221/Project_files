//
//  APIList.swift
//  FIEXFIT
//
//  Created by SAIL on 26/12/23.
//

import Foundation
struct APIList
{
    
//    let BASE_URL = "http://localhost/flexfit/"
    
    let BASE_URL = "http://172.23.18.7/flexfit/"
    
    func urlString(url: urlString) -> String
    {
        return BASE_URL + url.rawValue
    }
}

enum urlString: String

{
    
    case PatientLoginAPI = "patient_login.php?"
    case DoctorLoginAPI = "login_page.php"
    case PatientList = "show_patient_list.php"
    case PatientProfileAPI = "patient_profile.php"
    case PatientUpdateProfileAPI = "patient_updateprofile.php"
    case AddPatientAPI = "add_patient.php"
    case doctorProfile = "doctor_profile.php"
    case DoctorUpdateProfile = "doctor_updateprofile.php"
    case weekAndSessionApi = "weeks_sessions.php?user_id="
    case displaySessionApi = "display_sessions.php?category="
    case selectTitleApi = "select_titles.php?category"
    case patientVideoDisplay = "patient_videos_display.php?user_id="
    case onlinePatientListGraphApi = "online_patientlist_graph.php?"
    case offlinePatientListGraphApi = "offline_patientlist_graph.php?"
    case patientGraphApi = "patient_graph.php?user_id="
    case addVideoApi = "add_exercises.php"
    case patientVideoListApi = "patient_video_list.php"
    case patientFeedbackResponcesApi = "feedback_responses.php"
    case fetchFeedBackResponcesApi = "fetch_the_responses.php"
    case savedVideosApi = "saved_videos.php"
    case PatientRecoredVideo = "patient_recorded_videos.php"
    case DisplayVideoTitleApi = "display_video_titles.php?category="
}
 
