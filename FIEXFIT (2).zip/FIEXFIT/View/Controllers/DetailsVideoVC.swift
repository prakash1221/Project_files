//
//  DetailsVideoVC.swift
//  FIEXFIT
//
//  Created by Saranya Ravi on 25/11/23.
//

import UIKit
import AVKit
import AVFoundation

class DetailsVideoVC: UIViewController {

    @IBOutlet weak var exerciseVideoView: UIView!
//    var selectedVideo: ExerciseVideo?

    override func viewDidLoad() {
        super.viewDidLoad()
//        let player = AVPlayer(url: selectedVideo?.videoURL ?? URL(string: "")!)
//        let playerLayer = AVPlayerLayer(player: player)
//        exerciseVideoView.layer.addSublayer(playerLayer)
//               player.play()

      
    }
    

    

}
