import UIKit

class AddExercisesVc: BasicVC {
    
    @IBOutlet weak var patientIDTxt: UITextField!
    @IBOutlet weak var weekIDLbl: UILabel!
    @IBOutlet weak var ex3Lbl: UILabel!
    @IBOutlet weak var ex4Lbl: UILabel!
    @IBOutlet weak var tableBackgroundView: UIView!
    @IBOutlet weak var tablesView: UITableView!
    
    var type: String = ""
    var exerciseListData: [DisplaySessionNameData] = []
    var stabilityExercises: [String] = []
    var mobilityExercises: [String] = []
    var proprioceptionExercises: [String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        patientIDTxt.text = UserDefaultsManager.shared.getnamekey() ?? ""
        tableBackgroundView.isHidden = true
        tablesView.delegate = self
        tablesView.dataSource = self
        tablesView.register(UINib.init(nibName: "SessionListTVC", bundle: nil), forCellReuseIdentifier: "SessionListTVC")
        tablesView.allowsMultipleSelection = true
    }
    
    @IBAction func onSave(_ sender: Any) {
        print("Stability Exercises: \(stabilityExercises)")
        print("Mobility Exercises: \(mobilityExercises)")
        print("Proprioception Exercises: \(proprioceptionExercises)")
                postAPI()
    }
    
    @IBAction func onBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func weekButton(_ sender: Any) {
        let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "DropDownVc") as! DropDownVc
        vc.selectedBtnTag = 1
        vc.delegate1 = self
        vc.modalPresentationStyle = .overCurrentContext
        self.present(vc, animated: false, completion: nil)
    }
    
    @IBAction func stabilityButton(_ sender: Any) {
        
        tableBackgroundView.isHidden = !tableBackgroundView.isHidden
        if !tableBackgroundView.isHidden {
            type = "stability"
            getApi(type: type)
        }
    }
    
    
    @IBAction func mobilityButton(_ sender: Any) {
        
        tableBackgroundView.isHidden = !tableBackgroundView.isHidden
        if !tableBackgroundView.isHidden {
            type = "mobility"
            getApi(type: type)
        }
    }
    
    @IBAction func proButton(_ sender: Any) {
        
        tableBackgroundView.isHidden = !tableBackgroundView.isHidden
        if !tableBackgroundView.isHidden {
            type = "proprioception"
            getApi(type: type)
        }
    }
    
    
}

extension AddExercisesVc {
    func getApi(type: String) {
        startIndicator()
        let apiUrl = APIList().urlString(url: .displaySessionApi) + type
        APIHandler().getAPIValues(type: DisplaySessionNameModel.self, apiUrl: apiUrl, method: "GET") { [weak self] result in
            guard let self = self else { return }
            switch result {
            case .success(let data):
                DispatchQueue.main.async {
                    self.stopIndicator()
                    self.exerciseListData = data.data
                    self.tablesView.reloadData()
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    self.stopIndicator()
                    self.showAlert(title: "Failure", message: "Something Went Wrong", okActionHandler: {})
                }
            }
        }
    }
    func postAPI() {
        self.startIndicator()
        let apiURL = APIList().urlString(url:.selectTitleApi)
        
        let formData: [String: Any] = [
            "user_id": UserDefaultsManager.shared.getnamekey() ?? "",
            "week": "\(self.weekIDLbl.text ?? "")",
            "stability": stabilityExercises,
            "mobility": mobilityExercises,
            "proprioception": proprioceptionExercises
        ]
        
        APIHandler().postAPIValues(type: AddCandidateModel.self, apiUrl: apiURL, method: "POST", formData: formData) {  result in
            switch result {
            case .success(let data):
                DispatchQueue.main.async { [self] in
                    if data.status == true {
                        showAlert(title: "Success", message: data.message, okActionHandler: {})
                    } else if data.status == false {
                        showToast(data.message)
                    }
                    stopIndicator()
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    self.stopIndicator()
                    self.showAlert(title: "Failure", message: "Something Went Wrong", okActionHandler: {})
                }
            }
        }
    }
}


extension AddExercisesVc: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return exerciseListData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tablesView.dequeueReusableCell(withIdentifier: "SessionListTVC", for: indexPath) as! SessionListTVC
        let exercise = exerciseListData[indexPath.row].videoTitle
        cell.sessionLbl.text = exercise
        cell.selectionStyle = .default // or .none
        
        var selectedExercises: [String] = []
        switch type {
        case "stability":
            selectedExercises = stabilityExercises
        case "mobility":
            selectedExercises = mobilityExercises
        case "proprioception":
            selectedExercises = proprioceptionExercises
        default:
            break
        }
        
        // Check if the exercise is selected
        if selectedExercises.contains(exercise) {
            cell.accessoryType = .checkmark // Display checkmark
        } else {
            cell.accessoryType = .none // Hide checkmark
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let selectedExercise = exerciseListData[indexPath.row].videoTitle
        var selectedExercises: [String] = []
        switch type {
        case "stability":
            selectedExercises = stabilityExercises
        case "mobility":
            selectedExercises = mobilityExercises
        case "proprioception":
            selectedExercises = proprioceptionExercises
        default:
            break
        }
        
        // Toggle selection state
        if selectedExercises.contains(selectedExercise) {
            switch type {
            case "stability":
                if let index = stabilityExercises.firstIndex(of: selectedExercise) {
                    stabilityExercises.remove(at: index)
                }
            case "mobility":
                if let index = mobilityExercises.firstIndex(of: selectedExercise) {
                    mobilityExercises.remove(at: index)
                }
            case "proprioception":
                if let index = proprioceptionExercises.firstIndex(of: selectedExercise) {
                    proprioceptionExercises.remove(at: index)
                }
            default:
                break
            }
        } else {
            switch type {
            case "stability":
                stabilityExercises.append(selectedExercise)
            case "mobility":
                mobilityExercises.append(selectedExercise)
            case "proprioception":
                proprioceptionExercises.append(selectedExercise)
            default:
                break
            }
        }
        tableView.reloadRows(at: [indexPath], with: .automatic) // Reload the selected row
    }
    
    func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
        let deselectedExercise = exerciseListData[indexPath.row].videoTitle
        switch type {
        case "stability":
            if let index = stabilityExercises.firstIndex(of: deselectedExercise) {
                stabilityExercises.remove(at: index)
            }
        case "mobility":
            if let index = mobilityExercises.firstIndex(of: deselectedExercise) {
                mobilityExercises.remove(at: index)
            }
        case "proprioception":
            if let index = proprioceptionExercises.firstIndex(of: deselectedExercise) {
                proprioceptionExercises.remove(at: index)
            }
        default:
            break
        }
        tableView.reloadRows(at: [indexPath], with: .automatic) // Reload the deselected row
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
}

extension AddExercisesVc: dropdownProto {
    func VideosName(Name: String) {
    }
    
    func weekResult(Week: String) {
        self.weekIDLbl.text = Week
    }
}
