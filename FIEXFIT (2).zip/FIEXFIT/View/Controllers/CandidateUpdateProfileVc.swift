//
//  CandidateUpdateProfileVc.swift
//  FIEXFIT
//
//  Created by Saranya Ravi on 07/11/23.
//

import UIKit

class CandidateUpdateProfileVc: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
//    override func viewWillAppear(_ animated: Bool) {
//        self.navigationController?.isNavigationBarHidden = true
//    }

}
