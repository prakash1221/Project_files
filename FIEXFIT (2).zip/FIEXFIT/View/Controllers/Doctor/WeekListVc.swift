//
//  WeekListVc.swift
//  FIEXFIT
//
//  Created by Saranya Ravi on 29/11/23.
//

import UIKit

class WeekListVc: BasicVC {

   

    @IBOutlet weak var weekTable : UITableView!{
        didSet{
            weekTable.delegate = self
            weekTable.dataSource = self
            weekTable.register(UINib.init(nibName: "SessionListTVC", bundle: nil), forCellReuseIdentifier: "SessionListTVC")
        }
    }
    var weekData : [WeekAndSessionData] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        getApi()
       
       
    }
    
    @IBAction func backTap(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    

    @IBAction func onBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    
}

extension WeekListVc: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return weekData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SessionListTVC", for: indexPath) as! SessionListTVC
        cell.sessionLbl.text = "Week \(weekData[indexPath.row].weekNumber)"
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100.0
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let selectedWeekData = weekData[indexPath.row]
        let vc = storyboard?.instantiateViewController(withIdentifier: "SessionListVc") as! SessionListVc
        
        vc.weekData = selectedWeekData
        vc.weekCount = "\(weekData[indexPath.row].weekNumber)"
        navigationController?.pushViewController(vc, animated: true)
    }
}
extension WeekListVc {
    func getApi() {
        
        let patientID = UserDefaultsManager.shared.getnamekey() ?? ""
        
            let apiURL = APIList().urlString(url:.weekAndSessionApi) + patientID
        APIHandler().getAPIValues(type: WeekAndSessionModel.self, apiUrl: apiURL, method: "GET") {  result in
                switch result {
                case .success(let data):
                    DispatchQueue.main.async { [self] in
                    if data.status == true{
                        weekData = data.data
                        weekTable.reloadData()
                     }
                    else if data.status == false{
                           showToast(data.message)
                        }
                        self.stopIndicator()
                    }
                    case .failure(let error):
                    print(error)
                    DispatchQueue.main.async {
                        self.stopIndicator()
                        self.showAlert(title: "Failure", message: "Something Went Wrong", okActionHandler: {})
                    }
                }
            }
        }
}
