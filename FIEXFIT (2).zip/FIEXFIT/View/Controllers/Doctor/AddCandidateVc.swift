//
//  AddCandidateVc.swift
//  FIEXFIT
//
//  Created by Saranya Ravi on 07/11/23.
//

import UIKit

class AddCandidateVc: BasicVC,UIImagePickerControllerDelegate , UINavigationControllerDelegate {
    
    @IBOutlet weak var candidateImg: UIImageView!
    
    @IBOutlet weak var CandidateID : UITextField!
    @IBOutlet weak var CandidateName : UITextField!
    @IBOutlet weak var CandidateAge : UITextField!
    @IBOutlet weak var CandidateGender : UITextField!
    @IBOutlet weak var mobileLabel : UITextField!
    @IBOutlet weak var candidateType : UITextField!
    @IBOutlet weak var FMSScore : UITextField!
    @IBOutlet weak var password : UITextField!
    @IBOutlet weak var dropDownView: UIView!
    @IBOutlet weak var saveBtn: UIButton!
    @IBOutlet weak var profileImage: UIImageView!
    
    var positionArray = ["Online", "Offline"]
    let imagePicker = UIImagePickerController()
    var selectedProfileImage = [UIImage]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        imagePicker.delegate = self
        imagePicker.allowsEditing = true
        saveBtn.layer.cornerRadius = 15
        dropDownView.isHidden = true
    }
    @IBAction func editImage(_ sender: Any) {
        
        presentImagePicker()
    }
    func presentImagePicker() {
           let alert = UIAlertController(title: "Choose Image", message: nil, preferredStyle: .actionSheet)
           alert.addAction(UIAlertAction(title: "Camera", style: .default, handler: { _ in
               self.openCamera()
           }))
           alert.addAction(UIAlertAction(title: "Gallery", style: .default, handler: { _ in
               self.openGallery()
           }))
           alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
           present(alert, animated: true, completion: nil)
       }
       
    func openCamera() {
           if UIImagePickerController.isSourceTypeAvailable(.camera) {
               imagePicker.sourceType = .camera
               selectedProfileImage.removeAll()
               present(imagePicker, animated: true, completion: nil)
           } else {
               print("Camera not available")
           }
       }
       
    func openGallery() {
           imagePicker.sourceType = .photoLibrary
           selectedProfileImage.removeAll()
           present(imagePicker, animated: true, completion: nil)
       }

    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let pickedImage = info[UIImagePickerController.InfoKey.editedImage] as? UIImage {
            selectedProfileImage.append(pickedImage)
            candidateImg.image = pickedImage
        }
        picker.dismiss(animated: true, completion: nil)
    }
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
           picker.dismiss(animated: true, completion: nil)
       }
    
    @IBAction func typeTapped(_ sender: Any) {
        
        if !dropDownView.isHidden {
            dropDownView.isHidden = true
        }else {
            dropDownView.isHidden = false
        }
    }
    
    @IBAction func backTap(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func onllineTap(_ sender: Any) {

        dropDownView.isHidden = true
        candidateType.text = "Online"
    }

    @IBAction func offlineTap(_ sender: Any) {
        candidateType.text = "Offline"
        dropDownView.isHidden = true
    }
    
    @IBAction func saveTap(_ sender: Any) {
        updateProfile()
        
    }


    
}
extension AddCandidateVc{
    func updateProfile() {
        
        let apiURL = APIList().urlString(url:.AddPatientAPI)
        print("API URL:", apiURL)

        let boundary = UUID().uuidString
        var request = URLRequest(url: URL(string: apiURL)!)
        request.httpMethod = "POST"
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        var body = Data()
        let formData = ["user_id" : "\(self.CandidateID.text ?? "")",
                        "patient_name":"\(self.CandidateName.text ?? "")",
                        "mobile_number":"\(self.mobileLabel.text ?? "")",
                        "dob":"\(self.CandidateAge.text ?? "")",
                        "FMS_Score":"\(self.FMSScore.text ?? "")",
                        "gender":"\(self.CandidateGender.text ?? "")",
                        "connection_type":"\(self.candidateType.text ?? "")",
                        "password":"\(self.password.text ?? "")"]
        
        for (key, value) in formData {
            body.append(contentsOf: "--\(boundary)\r\n".utf8)
            body.append(contentsOf: "Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n".utf8)
            body.append(contentsOf: "\(value)\r\n".utf8)
        }
        let fieldNames = ["photo"]
        for (index, image) in selectedProfileImage.enumerated() {
            let fieldName = fieldNames[index]
            let imageData = image.jpegData(compressionQuality: 0.8)!
            body.append(contentsOf: "--\(boundary)\r\n".utf8)
            body.append(contentsOf: "Content-Disposition: form-data; name=\"\(fieldName)\"; filename=\"\(UUID().uuidString).jpg\"\r\n".utf8)
            body.append(contentsOf: "Content-Type: image/jpeg\r\n\r\n".utf8)
            body.append(contentsOf: imageData)
            body.append(contentsOf: "\r\n".utf8)
        }
        body.append(contentsOf: "--\(boundary)--\r\n".utf8) // Close the request body
        request.httpBody = body
        let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
            if let error = error {
                print("Error: \(error)")
                return
            }
            if let httpResponse = response as? HTTPURLResponse {
                print("Status code: \(httpResponse.statusCode)")
                self.selectedProfileImage.removeAll()
                if let data = data {
                     print("Response Data:", String(data: data, encoding: .utf8) ?? "")
                    if let responseData = String(data: data, encoding: .utf8) {
                        if let jsonData = responseData.data(using: .utf8) {
                            do {
                                if let json = try JSONSerialization.jsonObject(with: jsonData, options: []) as? [String: Any] {
                                    if let status = json["status"] as? Bool, let message = json["message"] as? String {
                                        print(message)
                                        print(status)
                                        
                                        DispatchQueue.main.async {
                                            if let nav = self.navigationController {
                                                self.showAlert(title: "Success", message: message,okActionHandler: {
                                                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "Doctors_HomePG")
                                                    as! Doctors_HomePG
                                                    self.navigationController?.pushViewController(vc, animated: true)
                                                })
                                            }
                                        }
                                    }
                                }
                            } catch {
                                print("Error parsing JSON: \(error)")
                            }
                        }
                    }
                }
            }
            
        }

        task.resume()
    }
}
