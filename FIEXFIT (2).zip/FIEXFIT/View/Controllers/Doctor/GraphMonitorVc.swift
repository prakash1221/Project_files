//
//  GraphMonitorVc.swift
//  FIEXFIT
//
//  Created by Saranya Ravi on 09/11/23.
//

import UIKit
import Charts

class GraphMonitorVc: BasicVC {

    @IBOutlet weak var onlineGraphView: PieChartView!
    @IBOutlet weak var offlineGraphView: PieChartView!
    
    var onlineCompleted  : Double = 0.0
    var onlinePending  : Double = 0.0
    var offlineCompleted  : Double = 0.0
    var offlinePending : Double = 0.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        getApi()
        get1Api()
        
    }

    @IBAction func backTap(_ sender: Any) {
        
        self.navigationController?.popViewController(animated: true)
    }
}
extension GraphMonitorVc {
    func getApi() {
        self.startIndicator()
            let apiURL = APIList().urlString(url:.onlinePatientListGraphApi)
        APIHandler().getAPIValues(type: GraphModel.self, apiUrl: apiURL, method: "GET") {  result in
                switch result {
                case .success(let data):
                    DispatchQueue.main.async { [self] in
                    if data.status == true{
                        onlineCompleted = Double("\(data.data.first?.completed ?? "")") ?? 0.0
                        onlinePending = Double("\(data.data.first?.pending ?? "")") ?? 0.0
                        print("onlineCompleted : \(onlineCompleted)")
                        print("onlinePending : \(onlinePending)")
                        let graphData = ["Completed", "Pending"]
                        setChart(dataPoints: graphData, values: [onlineCompleted,onlinePending], chart: onlineGraphView)
                     }
                    else if data.status == false{
                           showToast(data.message)
                        }
                        self.stopIndicator()
                    }
                    case .failure(let error):
                    print(error)
                    DispatchQueue.main.async {
                        self.stopIndicator()
                        self.showAlert(title: "Failure", message: "Something Went Wrong", okActionHandler: {})
                    }
                }
            }
        }
    func get1Api() {
        self.startIndicator()
            let apiURL = APIList().urlString(url:.offlinePatientListGraphApi)
        APIHandler().getAPIValues(type: GraphModel.self, apiUrl: apiURL, method: "GET") {  result in
                switch result {
                case .success(let data):
                    DispatchQueue.main.async { [self] in
                    if data.status == true{
                        offlineCompleted = Double("\(data.data.first?.completed ?? "")") ?? 0.0
                        offlinePending = Double("\(data.data.first?.pending ?? "")") ?? 0.0
                        print("offlineCompleted : \(offlineCompleted)")
                        print("offlinePending : \(offlinePending)")
                        setChart(dataPoints: ["Completed", "Pending"], values: [offlineCompleted,offlinePending], chart: offlineGraphView)
                     }
                    else if data.status == false{
                           showToast(data.message)
                        }
                        self.stopIndicator()
                    }
                    case .failure(let error):
                    print(error)
                    DispatchQueue.main.async {
                        self.stopIndicator()
                        self.showAlert(title: "Failure", message: "Something Went Wrong", okActionHandler: {})
                    }
                }
            }
        }
}
