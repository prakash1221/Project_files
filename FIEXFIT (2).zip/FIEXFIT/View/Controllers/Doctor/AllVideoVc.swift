//
//  AllVideoVc.swift
//  FIEXFIT
//
//  Created by SAIL on 07/02/24.
//

import UIKit
import AVKit
import AVFoundation

extension AllVideoVc: dropdownProto {
    func VideosName(Name: String) {
      getApi(type: Name)
        self.selectTypeButton.setTitle(Name, for: .normal)
    }
    
    func weekResult(Week: String) {
//        self.weekIDLbl.text = Week
    }
}
class AllVideoVc: BasicVC {

    @IBOutlet weak var selectTypeButton: UIButton!
    @IBOutlet weak var showVideosTableView: UITableView! {
        didSet {
            showVideosTableView.delegate = self
            showVideosTableView.dataSource = self
            showVideosTableView.register(UINib(nibName: "ExerciseListTVC", bundle: nil), forCellReuseIdentifier: "ExerciseListTVC")
        }
    }
    var type: String = ""
    var player: AVPlayer?
    var exerciseListData: [DisplaySessionNameData] = []
    
    
    override func viewDidLoad() {
        super.viewDidLoad()


    }
    func fetchThumbnail(for videoURL: String, completion: @escaping (UIImage?) -> Void) {
        guard let url = URL(string: videoURL) else {
            completion(nil)
            return
        }
        
        let asset = AVAsset(url: url)
        let generator = AVAssetImageGenerator(asset: asset)
        generator.appliesPreferredTrackTransform = true
        
        let time = CMTimeMakeWithSeconds(0.5, preferredTimescale: 600)
        do {
            let cgImage = try generator.copyCGImage(at: time, actualTime: nil)
            let thumbnail = UIImage(cgImage: cgImage)
            completion(thumbnail)
        } catch {
            print("Error generating thumbnail: \(error.localizedDescription)")
            completion(nil)
        }
    }
    @IBAction func backTap(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func selectTypeButtonAct(_ sender: Any) {
        let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "DropDownVc") as! DropDownVc
        vc.selectedBtnTag = 2
        vc.delegate1 = self
        vc.modalPresentationStyle = .overCurrentContext
        self.present(vc, animated: false, completion: nil)
    }
   
}
extension AllVideoVc : UITableViewDelegate, UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return exerciseListData.count // Return the number of titles
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = showVideosTableView.dequeueReusableCell(withIdentifier: "ExerciseListTVC", for: indexPath) as! ExerciseListTVC
        cell.videoTitleLabel.text = exerciseListData[indexPath.row].videoTitle
        let apiUrl = "\(APIList().BASE_URL)"+"\(exerciseListData[indexPath.row].videoPath)"
        print(apiUrl)
        guard let videoURL = URL(string: apiUrl) else {
            cell.videoImage.image = UIImage(named: "AppLogo")
            return cell
        }
        
        fetchThumbnail(for: videoURL.absoluteString) { thumbnailImage in
            DispatchQueue.main.async {
                cell.videoImage.image = thumbnailImage ?? UIImage(named: "AppLogo")
            }
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ShowVideoVC") as! ShowVideoVC
        vc.name = exerciseListData[indexPath.row].videoTitle
        vc.videoData = "\(APIList().BASE_URL)"+"\(exerciseListData[indexPath.row].videoPath)"
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }
}
extension AllVideoVc {
    
    func getApi(type : String) {
        startIndicator()
        let apiUrl = APIList().urlString(url:.displaySessionApi) + type
        APIHandler().getAPIValues(type: DisplaySessionNameModel.self, apiUrl: apiUrl, method: "GET") { [weak self] result in
            guard let self = self else { return }
            switch result {
            case.success(let data):
                DispatchQueue.main.async {
                    self.stopIndicator()
                    // Extract titles from data and update the array
                    self.exerciseListData = data.data
                    self.showVideosTableView.reloadData()
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    self.stopIndicator()
                    self.showAlert(title: "Failure", message: "Something Went Wrong", okActionHandler: {})
                }
            }
        }
    }
}
