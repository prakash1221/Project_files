//
//  ViewCandidateVc.swift
//  FIEXFIT
//
//  Created by Saranya Ravi on 07/11/23.
//

import UIKit

class ViewCandidateVc: BasicVC {
    
    @IBOutlet weak var viewperformaceBtn: UIButton!
    @IBOutlet weak var patientVideoBtn: UIButton!
    @IBOutlet weak var addExcersiseBtn: UIButton!
    @IBOutlet weak var patientIDLabel: UILabel!
    @IBOutlet weak var patientNameLabel: UILabel!
    @IBOutlet weak var ageLabel: UILabel!
    @IBOutlet weak var genderLabel: UILabel!
    @IBOutlet weak var fmsScoreLabel: UILabel!
    @IBOutlet weak var typeLabel: UILabel!
    @IBOutlet weak var mobileLabel: UILabel!
    
    @IBOutlet weak var patientImage: UIImageView!
    @IBOutlet weak var addButtonOutlet: UIButton!
    
    var patientId = ""
    var connectionType = "Online"
    override func viewDidLoad() {
        super.viewDidLoad()
        postAPI()
        
        viewperformaceBtn.layer.cornerRadius = 10
        
        addExcersiseBtn.layer.cornerRadius = 10
        
    }
   
    @IBAction func backtap(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func viewPerformance(_ sender: Any) {
        
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "ViewPerformanceVc") as! ViewPerformanceVc
        vc.patientId = patientId
        self.navigationController?.pushViewController(vc, animated: true)
    } 
    @IBAction func patientVideoAction(_ sender: Any) {
        
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "PatientRecordVideoListVC") as! PatientRecordVideoListVC
        vc.patientId = patientId
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func onAddExercise(_ sender: Any) {
        if connectionType == "Offline"{
//            showAlert(title: "Update", message: "Next update Offline Patient will show")
            let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyBoard.instantiateViewController(withIdentifier: "PatientDailyProgress") as! PatientDailyProgress
            vc.connectionType = connectionType
            vc.patientID = patientId
            self.navigationController?.pushViewController(vc, animated: true)
        }else{
            let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyBoard.instantiateViewController(withIdentifier: "DailyExerciseListVc") as! DailyExerciseListVc
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
}
extension ViewCandidateVc{
    
    func postAPI(){
        self.startIndicator()
       
            let apiURL = APIList().urlString(url:.PatientProfileAPI)
            let formData = ["user_id" : patientId]
        
            APIHandler().postAPIValues(type: PatientProfileModel.self, apiUrl: apiURL, method: "POST", formData: formData) {  result in
                switch result {
                case .success(let data):
                    DispatchQueue.main.async { [self] in
                    if data.status == true{
                        DispatchQueue.main.async{ [self] in
                            let details = data.patientProfile
                            
                            patientIDLabel.text = details.userID
                            patientNameLabel.text = details.patientName
                            ageLabel.text = details.dob
                            genderLabel.text = details.gender
                            fmsScoreLabel.text = details.fmsScore
                            mobileLabel.text = details.mobileNumber
                            typeLabel.text = details.connectionType
                            if typeLabel.text == "Offline"{
                                addButtonOutlet.setTitle("Enter Performance", for: .normal)
                                connectionType = "Offline"
                                patientVideoBtn.isHidden = true
                            }
                            let imageName = details.photo
                            let imageURL = URL(string: APIList().BASE_URL + imageName)

                            let task = URLSession.shared.dataTask(with: imageURL!) { data, response, error in
                                if let error = error {
                                    print("Error loading image: \(error.localizedDescription)")
                                    // Set a placeholder image if loading fails
                                    DispatchQueue.main.async {
                                        self.patientImage.image = UIImage(named: "Image-8")
                                    }
                                    return
                                }
                                
                                if let data = data, let image = UIImage(data: data) {
                                    // Set the downloaded image on the main thread
                                    DispatchQueue.main.async {
                                        self.patientImage.image = image
                                    }
                                } else {
                                    print("Invalid image data")
                                    // Set a placeholder image if loading fails
                                    DispatchQueue.main.async {
                                        self.patientImage.image = UIImage(named: "Image-8")
                                    }
                                }
                            }
                            task.resume()


                            
                        }
                        
                     }
                    else if data.status == false{
                            showToast(data.message )
                        }
                        stopIndicator()
                    }
                    case .failure(let error):
                    print(error)
                    DispatchQueue.main.async {
                        self.stopIndicator()
                        self.showAlert(title: "Failure", message: "Something Went Wrong", okActionHandler: {})
                    }
                }
               }
        }
    
}
