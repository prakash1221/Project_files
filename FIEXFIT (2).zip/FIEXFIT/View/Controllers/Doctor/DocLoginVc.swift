//
//  DocLoginVc.swift
//  FIEXFIT
//
//  Created by Saranya Ravi on 07/11/23.
//

import UIKit

class DocLoginVc: BasicVC {

    @IBOutlet weak var docIDTxt: UITextField!
    @IBOutlet weak var docPasswordTxt: UITextField!
    @IBOutlet weak var docIdView: UIView!
    @IBOutlet weak var loginBtn: UIButton!
    @IBOutlet weak var eyeimagebutton: UIButton!
    @IBOutlet weak var passView: UIView!
    @IBOutlet weak var titleLoginLabel: UILabel!
    
    var titleLabelString = ""
    var iconClick = true
    
    override func viewDidLoad() {
        super.viewDidLoad()
        titleLoginLabel.text = titleLabelString
        if UserDefaultsManager.shared.getUserName() == "Candidate" {
            docIDTxt.placeholder = "Candidate ID"
        }
    }
    
    @IBAction func onBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func eyeButton(_ sender: UIButton) {
      
        docPasswordTxt.isSecureTextEntry.toggle()
           
           let imageName = docPasswordTxt.isSecureTextEntry ? "eye.slash" : "eye"
           
           // Set the image based on password visibility, fallback to a system image if custom image is not found
           eyeimagebutton.setImage(UIImage(named: imageName) ?? UIImage(systemName: imageName), for: .normal)


        
    }
    
    @IBAction func onDocLogin(_ sender: Any) {
        if docIDTxt.text?.isEmpty == true{
            showToast("Enter the ID")
        } else if docPasswordTxt.text?.isEmpty == true {
            showToast("Enter the Password")
        }else{
            postAPI()
        }
    }
}

extension DocLoginVc{
    
    func postAPI(){
        self.startIndicator()
        if UserDefaultsManager.shared.getUserName() == "Doctor"{
            let apiURL = APIList().urlString(url:.DoctorLoginAPI)
            let formData = ["doctor_id" : "\(self.docIDTxt.text ?? "")",
                            "password":"\(self.docPasswordTxt.text ?? "")"]
        
            APIHandler().postAPIValues(type: DoctorLoginModel.self, apiUrl: apiURL, method: "POST", formData: formData) {  result in
                switch result {
                case .success(let data):
                    DispatchQueue.main.async { [self] in
                        if data.status == true{
                            
                            UserDefaultsManager.shared.saveUserId(self.docIDTxt.text ?? "")
                            
                        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                        let vc = storyBoard.instantiateViewController(withIdentifier: "Doctors_HomePG") as! Doctors_HomePG
                        self.navigationController?.pushViewController(vc, animated: true)
                     }
                    else if data.status == false{
                            showToast(data.message )
                        }
                        stopIndicator()
                    }
                    case .failure(let error):
                    print(error)
                    DispatchQueue.main.async {
                        self.stopIndicator()
                        self.showAlert(title: "Failure", message: "Something Went Wrong", okActionHandler: {})
                    }
                }
               }
        }else if UserDefaultsManager.shared.getUserName() == "Candidate"{
            let apiURL = APIList().urlString(url:.PatientLoginAPI)
            let formData = ["user_id" : "\(self.docIDTxt.text ?? "")",
                            "password":"\(self.docPasswordTxt.text ?? "")"]
        
            APIHandler().postAPIValues(type: PatientLoginModel.self, apiUrl: apiURL, method: "POST", formData: formData) {  result in
                switch result {
                case .success(let data):
                    DispatchQueue.main.async { [self] in
                    if data.status == true{
                        UserDefaultsManager.shared.saveUserId(self.docIDTxt.text ?? "")
                        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                        let vc = storyBoard.instantiateViewController(withIdentifier: "CandidateHomeVc") as! CandidateHomeVc
                        self.navigationController?.pushViewController(vc, animated: true)
                     }
                    else if data.status == false{
                            showToast(data.message )
                        }
                        self.stopIndicator()
                    }
                    case .failure(let error):
                    print(error)
                    DispatchQueue.main.async {
                        self.stopIndicator()
                        self.showAlert(title: "Failure", message: "Something Went Wrong", okActionHandler: {})
                    }
                }
            }
        }
    }
}
