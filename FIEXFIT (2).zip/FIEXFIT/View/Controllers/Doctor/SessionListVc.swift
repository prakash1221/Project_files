//
//  SessionListVc.swift
//  FIEXFIT
//
//  Created by Saranya Ravi on 09/11/23.
//

import UIKit

class SessionListVc: UIViewController , UITableViewDelegate , UITableViewDataSource {
    
    @IBOutlet weak var sessionTable: UITableView! {
        didSet {
            sessionTable.delegate = self
            sessionTable.dataSource = self
        }
    }
    var weekData: WeekAndSessionData?
    var weekCount = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        sessionTable.register(UINib(nibName: "SessionListTVC", bundle: nil), forCellReuseIdentifier: "SessionListTVC")
        print("weekCount",weekCount)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // Return the number of sessions in the weekData
        return weekData?.days.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SessionListTVC", for: indexPath) as! SessionListTVC
        
        // Get the session number for the current indexPath
        if let sessionNumber = weekData?.days[indexPath.row].sessionNumber {
            cell.sessionLbl.text = "Session \(sessionNumber)"
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100.0
    }

    @IBAction func onBack(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "DailyExerciseMultipleVC") as! DailyExerciseMultipleVC
        vc.weekCount = weekCount
        if let sessionNumber = weekData?.days[indexPath.row].sessionNumber {
            vc.sessionCount = "\(sessionNumber)"
        }
       
        navigationController?.pushViewController(vc, animated: true)
    }
}
