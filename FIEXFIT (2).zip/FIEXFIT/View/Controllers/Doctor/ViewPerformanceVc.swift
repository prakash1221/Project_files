//
//  ViewPerformanceVc.swift
//  FIEXFIT
//
//  Created by Saranya Ravi on 09/11/23.
//

import UIKit
import Charts

class ViewPerformanceVc: BasicVC {
    
    @IBOutlet weak var graphView: PieChartView!
    @IBOutlet weak var openBtn: UIButton!
    
    var patientId = ""
    var patientSessions : Double = 0
    var patientPendingSessions : Double = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        getApi()
        openBtn.layer.cornerRadius = 10
    }
    

    @IBAction func openTap(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "WeekListVc") as! WeekListVc
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    @IBAction func backTap(_ sender: Any) {
        
        self.navigationController?.popViewController(animated: true)
    }
}
extension ViewPerformanceVc{
    
    func getApi() {
      
            let apiURL = APIList().urlString(url:.patientGraphApi) + patientId
        APIHandler().getAPIValues(type: PatientGraphModel.self, apiUrl: apiURL, method: "GET") {  result in
                switch result {
                case .success(let data):
                    DispatchQueue.main.async { [self] in
                    if data.status == true{
                        patientSessions = data.data.sessions
                        patientPendingSessions = data.data.pendingSession
                        print("patientSessions : \(patientSessions)")
                        print("patientPendingSessions : \(patientPendingSessions)")
                        setChart(dataPoints: ["Completed","Pending"], values: [patientSessions,patientPendingSessions], chart: graphView)                     }
                    else if data.status == false{
                           showToast(data.message)
                        }
                        self.stopIndicator()
                    }
                    case .failure(let error):
                    print(error)
                    DispatchQueue.main.async {
                        self.stopIndicator()
                        self.showAlert(title: "Failure", message: "Something Went Wrong", okActionHandler: {})
                    }
                }
            }
        }
}

