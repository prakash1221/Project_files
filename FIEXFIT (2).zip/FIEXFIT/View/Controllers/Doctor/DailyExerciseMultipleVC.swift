//
//  DailyExerciseMultipleVC.swift
//  FIEXFIT
//
//  Created by SAIL on 18/01/24.
//

import UIKit

class DailyExerciseMultipleVC: BasicVC {

    @IBOutlet weak var tableview: UITableView!{
        didSet{
            tableview.delegate = self
            tableview.dataSource = self
        }
    }
    var type: String = ""
    var weekCount = ""
    var sessionCount = ""
    var exerciseCompletion = ""
    var feedbackOption = ""
    var painScale = ""
    var exerciseListData: [String] = []
    var stabilityExercises: [String] = []
    var mobilityExercises: [String] = []
    var proprioceptionExercises: [String] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        getApi()
        tableview.register(UINib.init(nibName: "SessionListTVC", bundle: nil), forCellReuseIdentifier: "SessionListTVC")
        tableview.isHidden = true
    }
    @IBAction func onBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func stabilityButton(_ sender: Any) {
        
        tableview.isHidden = !tableview.isHidden
        if !tableview.isHidden {
            type = "stability"
            getApi()
        }
    }

    
    @IBAction func mobilityButton(_ sender: Any) {
        
        tableview.isHidden = !tableview.isHidden
        if !tableview.isHidden {
            type = "mobility"
            getApi()
        }
    }
    
    @IBAction func proButton(_ sender: Any) {
       
        tableview.isHidden = !tableview.isHidden
        if !tableview.isHidden {
            type = "proprioception"
            getApi()
        }
    }
    @IBAction func nextButton(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "feedback_question") as! feedback_question
        vc.painScale = painScale
        vc.feedbackOption = feedbackOption
        vc.exerciseCompletion = exerciseCompletion
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
}
extension DailyExerciseMultipleVC{
    func getApi() {
        startIndicator()
        let formDatas : [String: Any] = ["user_id" : UserDefaultsManager.shared.getnamekey() ?? "",
                                         "week_number" : weekCount,
                                         "session_number" : sessionCount]
        let apiUrl = APIList().urlString(url: .fetchFeedBackResponcesApi)
        APIHandler().postAPIValues(type: FetchResponseModel.self, apiUrl: apiUrl, method: "GET", formData: formDatas) { [weak self] result in
            guard let self = self else { return }
            switch result {
            case .success(let data):
                DispatchQueue.main.async {
                    self.stopIndicator()
                    self.painScale = data.data.painScale
                    self.feedbackOption = data.data.feedbackOption
                    self.exerciseCompletion = data.data.exerciseCompletion
                    self.stabilityExercises = data.data.stability
                    self.mobilityExercises = data.data.mobility
                    self.proprioceptionExercises = data.data.proprioception
                    self.tableview.reloadData()
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    self.stopIndicator()
                    self.showAlert(title: "Failure", message: "Something Went Wrong", okActionHandler: {})
                }
            }
        }
    }
}
extension DailyExerciseMultipleVC : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if type == "stability"{
            stabilityExercises.count
        }else if type == "mobility"{
            mobilityExercises.count
        }else if type == "proprioception"{
            proprioceptionExercises.count
        }else{
            0
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableview.dequeueReusableCell(withIdentifier: "SessionListTVC", for: indexPath) as! SessionListTVC
        if type == "stability"{
            let exercise = stabilityExercises[indexPath.row]
            cell.sessionLbl.text = exercise
        }else if type == "mobility"{
            let exercise = mobilityExercises[indexPath.row]
            cell.sessionLbl.text = exercise
        }else if type == "proprioception"{
            let exercise = proprioceptionExercises[indexPath.row]
            cell.sessionLbl.text = exercise
        }
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        80
    }


}
