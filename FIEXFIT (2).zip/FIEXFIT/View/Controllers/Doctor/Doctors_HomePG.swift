//
//  Doctors_HomePG.swift
//  FIEXFIT
//
//  Created by SAIL on 31/10/23.
//

import UIKit
import Charts
class Doctors_HomePG: BasicVC {

    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var sidemenuBtn: UIButton!
    @IBOutlet weak var patientListSegment: UISegmentedControl!
    
    @IBOutlet weak var patientTable: UITableView!
    
    var isSideMenuOpen: Bool = false
    var connectionType : Bool = true
    var patientListFetchData : PatientListModel!
    var onlineData : [PatientListData] = []
    var offlineData : [PatientListData] = []
    @IBOutlet weak var onlineGraphView: PieChartView!
    @IBOutlet weak var offlineGraphView: PieChartView!
    
    var onlineCompleted  : Double = 0.0
    var onlinePending  : Double = 0.0
    var offlineCompleted  : Double = 0.0
    var offlinePending : Double = 0.0
    

    @IBAction func backTap(_ sender: Any) {
        
        self.navigationController?.popViewController(animated: true)
    }

    func getApi() {
        self.startIndicator()
            let apiURL = APIList().urlString(url:.onlinePatientListGraphApi)
        APIHandler().getAPIValues(type: GraphModel.self, apiUrl: apiURL, method: "GET") {  result in
                switch result {
                case .success(let data):
                    DispatchQueue.main.async { [self] in
                    if data.status == true{
                        onlineCompleted = Double("\(data.data.first?.completed ?? "")") ?? 0.0
                        onlinePending = Double("\(data.data.first?.pending ?? "")") ?? 0.0
                        print("onlineCompleted : \(onlineCompleted)")
                        print("onlinePending : \(onlinePending)")
                        let graphData = ["Completed", "Pending"]
                        setChart(dataPoints: graphData, values: [onlineCompleted,onlinePending], chart: onlineGraphView)

                     }
                    else if data.status == false{
                           showToast(data.message)
                        }
                        self.stopIndicator()
                    }
                    case .failure(let error):
                    print(error)
                    DispatchQueue.main.async {
                        self.stopIndicator()
                        self.showAlert(title: "Failure", message: "Something Went Wrong", okActionHandler: {})
                    }
                }
            }
        }
    func get1Api() {
        self.startIndicator()
        let apiURL = APIList().urlString(url:.offlinePatientListGraphApi)
        APIHandler().getAPIValues(type: GraphModel.self, apiUrl: apiURL, method: "GET") {  result in
            switch result {
            case .success(let data):
                DispatchQueue.main.async { [self] in
                    if data.status == true{
                        offlineCompleted = Double("\(data.data.first?.completed ?? "")") ?? 0.0
                        offlinePending = Double("\(data.data.first?.pending ?? "")") ?? 0.0
                        print("offlineCompleted : \(offlineCompleted)")
                        print("offlinePending : \(offlinePending)")
                        setChart(dataPoints: ["Completed", "Pending"], values: [offlineCompleted,offlinePending], chart: offlineGraphView)
                        
                    }
                    else if data.status == false{
                        showToast(data.message)
                    }
                    self.stopIndicator()
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    self.stopIndicator()
                    self.showAlert(title: "Failure", message: "Something Went Wrong", okActionHandler: {})
                }
            }
        }
    }
        
    override func viewDidLoad() {
        super.viewDidLoad()
        sidemenuBtn.isHidden = false
        getApi()
        get1Api()
        postApi()
        let cell = UINib(nibName: "PatientListTVC", bundle: nil)
        patientTable.register(cell, forCellReuseIdentifier: "PatientListTVC")
       
        let onlineGraphSize = onlineGraphView.bounds.size
        let pieChartSize: CGFloat = 100
        let x = (onlineGraphSize.width - pieChartSize) / 2
        let y = (onlineGraphSize.height - pieChartSize) / 2
//        self.offlineGraphView.addPieChart(numberOfParts: 2, colors: [.lightGray,.yellow], x: x, y: y, size: pieChartSize, startAngle: -CGFloat.pi / 2)
//        self.onlineGraphView.addPieChart(numberOfParts: 2, colors: [.lightGray,.yellow], x: x, y: y, size: pieChartSize, startAngle: -CGFloat.pi / 2)
       
    }
    @IBAction func segmentButtonAction(_ sender: Any) {
        switch patientListSegment.selectedSegmentIndex {
            case 0:
            self.postApi()
            connectionType = true
            self.patientTable.reloadData()
            case 1:
            self.postApi()
            connectionType = false
            self.patientTable.reloadData()
            default:
                break;
            }
    }
    
    

    @IBAction func onSideMenu(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "SlideMenuVc") as! SlideMenuVc
        vc.sideDelegate = self
        vc.modalPresentationStyle = .overFullScreen
        self.present(vc, animated: false, completion: nil)
    
    }
    
    @IBAction func onMore(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "CandidateListVc") as! CandidateListVc
        if connectionType{
            vc.SendData = onlineData
        }else{
            vc.SendData = offlineData
        }
        self.navigationController?.pushViewController(vc, animated: true)
    }

    
}
extension Doctors_HomePG {
    func postApi(){
        self.startIndicator()
        let apiUrl = APIList().urlString(url:.PatientList)
        APIHandler().postAPIValues(type: PatientListModel.self, apiUrl: apiUrl, method: "POST", formData: [:]) { Result in
            switch Result {
            case.success(let data):
                DispatchQueue.main.async {
                    self.stopIndicator()
                        self.onlineData = data.data.filter{
                            ($0.connectionType == "Online")
                        }
                        self.offlineData = data.data.filter{
                            ($0.connectionType == "Offline")
                        }
                        print("offlineData : \(self.offlineData.count)")
                        print("onlineData : \(self.onlineData.count)")
                    self.patientListFetchData = data
                    self.patientTable.reloadData()
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    self.stopIndicator()
                    self.showAlert(title: "Failure", message: "Something Went Wrong", okActionHandler: {})
                }
            }
        }
    }
}
extension Doctors_HomePG : SlideMenuProto,UITableViewDelegate,UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if patientListSegment.selectedSegmentIndex == 0 {
            return onlineData.count
            
        }else{
            return offlineData.count
            
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "PatientListTVC", for: indexPath) as! PatientListTVC
        
        let dataToUse = patientListSegment.selectedSegmentIndex == 0 ? onlineData : offlineData
        guard indexPath.row < dataToUse.count else { return cell }
        
        let patient = dataToUse[indexPath.row]
        cell.numberLabel.text = "\(indexPath.row + 1)."
        cell.patientNameLabel.text = patient.name
        
        if let trimmedPhotoURL = patient.photo?.trimmingCharacters(in: .whitespaces), !trimmedPhotoURL.isEmpty {
            let imageURL = URL(string: APIList().BASE_URL + trimmedPhotoURL)
            
            let task = URLSession.shared.dataTask(with: imageURL!) { data, response, error in
                guard let data = data, let image = UIImage(data: data), error == nil else {
                    DispatchQueue.main.async {
                        cell.patientImg.image = UIImage(named: "Image-8")
                    }
                    return
                }
                DispatchQueue.main.async {
                    cell.patientImg.image = image
                }
            }
            task.resume()
        } else {
            DispatchQueue.main.async {
                cell.patientImg.image = UIImage(named: "Image-8")
            }
        }
        
        return cell
    }


    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70
    }
    func onSideMenu(menuNo: Int) {
        let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
        self.dismiss(animated: false, completion: nil)
        if menuNo == 1 {
//            let vc = storyboard.instantiateViewController(withIdentifier: "Doctors_HomePG") as! Doctors_HomePG
//            self.navigationController?.pushViewController(vc, animated: true)
           
        }else if menuNo == 2 {
            let vc = storyboard.instantiateViewController(withIdentifier: "DocViewProfileVc") as! DocViewProfileVc
            self.navigationController?.pushViewController(vc, animated: true)
        }else if menuNo == 3 {
            let vc = storyboard.instantiateViewController(withIdentifier: "GraphMonitorVc") as! GraphMonitorVc
            self.navigationController?.pushViewController(vc, animated: true)
        }else if menuNo == 4 {
            let vc = storyboard.instantiateViewController(withIdentifier: "AddCandidateVc") as! AddCandidateVc
            self.navigationController?.pushViewController(vc, animated: true)
        }else if menuNo == 5 {
            let vc = storyboard.instantiateViewController(withIdentifier: "VideoUploadVc") as! VideoUploadVc
            self.navigationController?.pushViewController(vc, animated: true)
        }else if menuNo == 6 {
            let vc = storyboard.instantiateViewController(withIdentifier: "AllVideoVc") as! AllVideoVc
            self.navigationController?.pushViewController(vc, animated: true)
        }else if menuNo == 7 {
            let vc = storyboard.instantiateViewController(withIdentifier: "loginVC") as! loginVC
            self.navigationController?.pushViewController(vc, animated: true)
        }else{
            print("LOGOUT MUST BE DONE")
        }
    }
}
