//
//  loginVC.swift
//  FIEXFIT
//
//  Created by SAIL on 20/09/23.
//

import UIKit

class loginVC: UIViewController {
    
    
    @IBOutlet weak var doctor: UIButton!
    @IBOutlet weak var candidate: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        doctor.layer.cornerRadius = 15
        candidate.layer.cornerRadius = 15
        
    }
    

    @IBAction func ondc(_ sender: Any) {
        UserDefaultsManager.shared.saveUserName("Doctor")
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "DocLoginVc") as! DocLoginVc
        vc.titleLabelString = "Doctor Login"
        self.navigationController?.pushViewController(vc, animated: true)
    }
   
    @IBAction func oncd(_ sender: Any) {
        UserDefaultsManager.shared.saveUserName("Candidate")
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "DocLoginVc") as! DocLoginVc
        vc.titleLabelString = "Candidate Login"
        self.navigationController?.pushViewController(vc, animated: true)

    }
    

}
