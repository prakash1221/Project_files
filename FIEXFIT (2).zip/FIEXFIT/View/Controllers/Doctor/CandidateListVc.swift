//
//  CandidateListVc.swift
//  FIEXFIT
//
//  Created by Saranya Ravi on 07/11/23.
//

import UIKit

class CandidateListVc: BasicVC {

    @IBOutlet weak var titleVc: UILabel!
    @IBOutlet weak var searchBarOutlet: UISearchBar! {
        didSet {
            searchBarOutlet.delegate = self
        }
    }

    @IBOutlet weak var candidiateListTable: UITableView!

    var SendData: [PatientListData] = []
    var originalSendData: [PatientListData] = []

    override func viewDidLoad() {
        super.viewDidLoad()

        // Assuming SendData is populated initially
        originalSendData = SendData

        let nib = UINib(nibName: "PatientListTVC", bundle: nil)
        candidiateListTable.register(nib, forCellReuseIdentifier: "PatientListTVC")
        candidiateListTable.delegate = self
        candidiateListTable.dataSource = self
        candidiateListTable.reloadData()
    }

    @IBAction func backTap(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }

    @IBAction func onBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
}

extension CandidateListVc: UISearchBarDelegate {

    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if searchText.isEmpty {
            SendData = originalSendData
        } else {
            SendData = originalSendData.filter { $0.name.lowercased().contains(searchText.lowercased()) }
        }
        candidiateListTable.reloadData()
    }
}


extension CandidateListVc: UITableViewDelegate, UITableViewDataSource {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return SendData.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = candidiateListTable.dequeueReusableCell(withIdentifier: "PatientListTVC", for: indexPath) as! PatientListTVC
        
        cell.numberLabel.text = "\(indexPath.row + 1)."
        cell.patientNameLabel.text = SendData[indexPath.row].name
        
        // Load and display the image asynchronously
        if let imageName = SendData[indexPath.row].photo, !imageName.isEmpty {
            let imageURL = URL(string: APIList().BASE_URL + imageName)
            
            let task = URLSession.shared.dataTask(with: imageURL!) { data, response, error in
                if let error = error {
                    print("Error loading image: \(error.localizedDescription)")
                    DispatchQueue.main.async {
                        cell.patientImg.image = UIImage(named: "placeholderImage")
                    }
                    return
                }
                
                if let data = data, let image = UIImage(data: data) {
                    // Set the downloaded image on the main thread
                    DispatchQueue.main.async {
                        cell.patientImg.image = image
                    }
                } else {
                    print("Invalid image data")
                    // Set a placeholder image if loading fails
                    DispatchQueue.main.async {
                        cell.patientImg.image = UIImage(named: "Image-8")
                    }
                }
            }
            task.resume()
        } else {
            // Set a placeholder image if the image name is empty
            cell.patientImg.image = UIImage(named: "Image-8")
        }
        
        return cell
    }


    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "ViewCandidateVc") as! ViewCandidateVc
        UserDefaultsManager.shared.savenameKey(SendData[indexPath.row].patientID )
        vc.patientId = SendData[indexPath.row].patientID
        self.navigationController?.pushViewController(vc, animated: true)
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80.0
    }
}
