//
//  VideoUploadVc.swift
//  FIEXFIT
//
//  Created by SAIL on 19/01/24.
//

import UIKit
import AVFoundation
import MobileCoreServices
import AVKit
extension VideoUploadVc: dropdownProto {
    func VideosName(Name: String) {
        self.selectTypeButton.setTitle(Name, for: .normal)
    }
    
    func weekResult(Week: String) {
//        self.weekIDLbl.text = Week
    }
}
class VideoUploadVc: BasicVC {

    @IBOutlet weak var uploadView: UIView!
    @IBOutlet weak var videoNameLbl: UITextField!
    @IBOutlet weak var uploadVdoBtn: UIButton!
    @IBOutlet weak var submitBtn: UIButton!
    @IBOutlet weak var selectTypeButton: UIButton!
    
    var videoURLName: URL?
    var selectVdo: String?
    
    override func viewDidLoad() {
        super.viewDidLoad()


    }
    @IBAction func selectTypeButtonAct(_ sender: Any) {
        let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "DropDownVc") as! DropDownVc
        vc.selectedBtnTag = 2
        vc.delegate1 = self
        vc.modalPresentationStyle = .overCurrentContext
        self.present(vc, animated: false, completion: nil)
    }
    @IBAction func uploadAtn(_ sender: Any) {
        if let videoURL = videoURLName {
            if videoNameLbl.text?.isEmpty == true{
                showToast("Please enter the Video Name")
            }else if selectTypeButton.currentTitle == "Select"{
                showToast("Please select the Type")
            }else{
                postAPI()
            }
           
        } else {
            showToast("Please select a video.")
        }
    }

    @IBAction func onBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func viewVdoAtn(_ sender: Any) {
        
//        if let videoUrl = videoURLName {
//              if UIApplication.shared.canOpenURL(videoUrl) {
//                  UIApplication.shared.open(videoUrl)
//              }
//          }
    }
    @IBAction func uploadVdoAtn(_ sender: Any) {
        let videoPicker = UIImagePickerController()
        videoPicker.sourceType = .photoLibrary
        videoPicker.mediaTypes = [kUTTypeMovie as String]
        videoPicker.videoExportPreset = AVAssetExportPreset1280x720
        videoPicker.delegate = self
        present(videoPicker, animated: true, completion: nil)
    }

}
extension VideoUploadVc: UIImagePickerControllerDelegate, UINavigationControllerDelegate{
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
        

        if let videoURL = info[.mediaURL] as? URL {
            // You can use the selected video URL here
            print("Selected video URL: \(videoURL)")
            self.uploadVideo(videoURL: videoURL,info: info)
        }
        picker.dismiss(animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
    
    func uploadVideo(videoURL:URL,info: [UIImagePickerController.InfoKey : Any]){
        if let fileSize = try? FileManager.default.attributesOfItem(atPath: videoURL.path)[.size] as? Int {
            let sizeInMegabytes = Double(fileSize) / (1024 * 1024)
            if sizeInMegabytes <= 10 {
                self.videoURLName = videoURL
                if let videoUrl = info[UIImagePickerController.InfoKey.mediaURL] as? URL {
                    let videoName = videoUrl.lastPathComponent
//                    uploadVdoLbl.text = videoName
                    uploadVdoBtn.setTitle("Video Added", for: .normal)
                    uploadVdoBtn.setImage(UIImage(systemName: "checkmark.seal.fill"), for: .normal)
//                    uploadVdoBtn.setTitleColor(UIColor.systemGreen, for: .normal)
                }
            } else{
                showToast("The video size must be under 10MB")
            }
            print("Video Size: \(sizeInMegabytes) MB")
        }
    }
}
extension VideoUploadVc{
    func postAPI(){
        self.startIndicator()
        let apiURL = APIList().urlString(url:.addVideoApi)
        print("API URL:", apiURL)
        let boundary = UUID().uuidString
        var request = URLRequest(url: URL(string: apiURL)!)
        request.httpMethod = "POST"
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        var body = Data()
        let formData: [String: Any] = [
            "video_title": videoNameLbl.text ?? "",
            "category": selectTypeButton.currentTitle ?? "",
            ]
        for (key, value) in formData {
            body.append(contentsOf: "--\(boundary)\r\n".utf8)
            body.append(contentsOf: "Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n".utf8)
            body.append(contentsOf: "\(value)\r\n".utf8)
        }
        print("formData :", formData)
        let videoData = try! Data(contentsOf: videoURLName!)
        body.append(contentsOf: "--\(boundary)\r\n".utf8)
        body.append(contentsOf: "Content-Disposition: form-data; name=\"video_path\"; filename=\"\(UUID().uuidString).mov\"\r\n".utf8)
        body.append(contentsOf: "Content-Type: video/quicktime\r\n\r\n".utf8)
        body.append(contentsOf: videoData)
        body.append(contentsOf: "\r\n".utf8)
        body.append(contentsOf: "--\(boundary)--\r\n".utf8) // Close the request body
        request.httpBody = body
        print("body :", body)
        let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
            if let error = error {
                print("Error: \(error)")
                return
            }
            if let httpResponse = response as? HTTPURLResponse {
                print("Status code: \(httpResponse.statusCode)")
                
                if let data = data {
                    print("Response Data:", String(data: data, encoding: .utf8) ?? "")
                    DispatchQueue.main.async {
                        self.stopIndicator()
                        self.showAlert(title: "Success", message: "Video information inserted into the database successfully", okActionHandler: {
                            let vc = self.storyboard?.instantiateViewController(withIdentifier: "Doctors_HomePG") as! Doctors_HomePG
                            self.navigationController?.pushViewController(vc, animated: true)
                        })
                    }
                }
            }
        }
        
        task.resume()
    }
}
