//
//  ExerciseListVc.swift
//  FIEXFIT
//
//  Created by Saranya Ravi on 14/11/23.
//

import UIKit

class ExerciseListVc: BasicVC ,UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var exerciseTable: UITableView! {
        didSet {
            exerciseTable.delegate = self
            exerciseTable.dataSource = self
        }
    }
    var type: String = ""
    var exerciseListData: [DisplaySessionNameData] = [] // Updated data structure to hold titles
    
    override func viewDidLoad() {
        super.viewDidLoad()
        exerciseTable.register(UINib(nibName: "ExerciseListTVC", bundle: nil), forCellReuseIdentifier: "ExerciseListTVC")
        getApi()
    }
    
    @IBAction func backTap(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return exerciseListData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = exerciseTable.dequeueReusableCell(withIdentifier: "ExerciseListTVC", for: indexPath) as! ExerciseListTVC
        cell.videoTitleLabel.text = exerciseListData[indexPath.row].videoTitle 
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        // Handle cell selection as needed
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }
    

}
extension ExerciseListVc{
    func getApi() {
        startIndicator()
        let apiUrl = APIList().urlString(url:.displaySessionApi) + type
        APIHandler().getAPIValues(type: DisplaySessionNameModel.self, apiUrl: apiUrl, method: "GET") { [weak self] result in
            guard let self = self else { return }
            switch result {
            case.success(let data):
                DispatchQueue.main.async {
                    self.stopIndicator()
                    // Extract titles from data and update the array
                    self.exerciseListData = data.data
                    self.exerciseTable.reloadData()
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    self.stopIndicator()
                    self.showAlert(title: "Failure", message: "Something Went Wrong", okActionHandler: {})
                }
            }
        }
    }
}
