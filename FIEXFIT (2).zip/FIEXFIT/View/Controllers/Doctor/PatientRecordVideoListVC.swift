//
//  PatientRecordVideoListVC.swift
//  FIEXFIT
//
//  Created by SAIL on 11/03/24.
//

import UIKit
import AVKit
import AVFoundation

extension PatientRecordVideoListVC: dropdownProto {
    func VideosName(Name: String) {
      
    }
    
    func weekResult(Week: String) {
        getApi(type: Week)
          self.selectTypeButton.setTitle(Week, for: .normal)
    }
}
class PatientRecordVideoListVC: BasicVC {

   
    @IBOutlet weak var selectTypeButton: UIButton!
    @IBOutlet weak var showVideosTableView: UITableView! {
        didSet {
            showVideosTableView.delegate = self
            showVideosTableView.dataSource = self
            showVideosTableView.register(UINib(nibName: "ExerciseListTVC", bundle: nil), forCellReuseIdentifier: "ExerciseListTVC")
        }
    }
    var type: String = ""
    var player: AVPlayer?
    var PatientRecodedVideoData: [PatientRecodedVideoData] = []
    var patientId = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()


    }
    func fetchThumbnail(for videoURL: String, completion: @escaping (UIImage?) -> Void) {
        guard let url = URL(string: videoURL) else {
            completion(nil)
            return
        }
        
        let asset = AVAsset(url: url)
        let generator = AVAssetImageGenerator(asset: asset)
        generator.appliesPreferredTrackTransform = true
        
        let time = CMTimeMakeWithSeconds(0.5, preferredTimescale: 600)
        do {
            let cgImage = try generator.copyCGImage(at: time, actualTime: nil)
            let thumbnail = UIImage(cgImage: cgImage)
            completion(thumbnail)
        } catch {
            print("Error generating thumbnail: \(error.localizedDescription)")
            completion(nil)
        }
    }
    @IBAction func backTap(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func selectTypeButtonAct(_ sender: Any) {
        let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "DropDownVc") as! DropDownVc
        vc.selectedBtnTag = 1
        vc.delegate1 = self
        vc.modalPresentationStyle = .overCurrentContext
        self.present(vc, animated: false, completion: nil)
    }
   
}
extension PatientRecordVideoListVC : UITableViewDelegate, UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return PatientRecodedVideoData.count // Return the number of titles
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = showVideosTableView.dequeueReusableCell(withIdentifier: "ExerciseListTVC", for: indexPath) as! ExerciseListTVC
        cell.videoTitleLabel.text = PatientRecodedVideoData[indexPath.row].videoTitle
        let apiUrl = "\(APIList().BASE_URL)"+"\(PatientRecodedVideoData[indexPath.row].recordedPatientVideo)"
        print(apiUrl)
        guard let videoURL = URL(string: apiUrl) else {
            cell.videoImage.image = UIImage(named: "AppLogo")
            return cell
        }
        
        fetchThumbnail(for: videoURL.absoluteString) { thumbnailImage in
            DispatchQueue.main.async {
                cell.videoImage.image = thumbnailImage ?? UIImage(named: "AppLogo")
            }
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ShowVideoVC") as! ShowVideoVC
        vc.name = PatientRecodedVideoData[indexPath.row].videoTitle
        vc.videoData = "\(APIList().BASE_URL)"+"\(PatientRecodedVideoData[indexPath.row].recordedPatientVideo)"
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }
}
extension PatientRecordVideoListVC {
    
    func getApi(type : String) {
        startIndicator()
        var formData = ["user_id":patientId ,
                        "week" : type]
        let apiUrl = APIList().urlString(url:.PatientRecoredVideo)
        APIHandler().postAPIValues(type: PatientRecodedVideoModel.self, apiUrl: apiUrl, method: "POST", formData: formData) { [weak self] result in
            guard let self = self else { return }
            switch result {
            case.success(let data):
                DispatchQueue.main.async {
                    self.stopIndicator()
                    self.PatientRecodedVideoData = data.data
                    self.showToast(data.message)
                    self.showVideosTableView.reloadData()
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    self.stopIndicator()
                    self.showAlert(title: "Failure", message: "Something Went Wrong", okActionHandler: {})
                }
            }
        }
    }
}
