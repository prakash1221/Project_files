//
//  CandidateHomeVc.swift
//  FIEXFIT
//
//  Created by Saranya Ravi on 10/11/23.
//

import UIKit

class CandidateHomeVc: BasicVC,SideMenuDelegate {
   
    

    
    @IBOutlet weak var homeCollectionView: UICollectionView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let flowLayout = UICollectionViewFlowLayout()
                flowLayout.minimumInteritemSpacing = 10
                flowLayout.minimumLineSpacing = 10
                flowLayout.scrollDirection = .vertical
        homeCollectionView.collectionViewLayout = flowLayout
        
        homeCollectionView.register(UINib(nibName: "CandidateHomeBannerCVC", bundle: nil), forCellWithReuseIdentifier: "CandidateHomeBannerCVC")
        homeCollectionView.register(UINib(nibName: "CandidateHomePerfCVC", bundle: nil), forCellWithReuseIdentifier: "CandidateHomePerfCVC")
        homeCollectionView.register(UINib(nibName: "CandidateHomeCategoriesCVC", bundle: nil), forCellWithReuseIdentifier: "CandidateHomeCategoriesCVC")
        homeCollectionView.delegate = self
        homeCollectionView.dataSource = self
        homeCollectionView.reloadData()
      
    }
    
    
    @IBAction func sideMenuTap(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "CandidateSideMenu") as! CandidateSideMenu
        vc.delegate = self
        vc.modalPresentationStyle = .overFullScreen
        self.present(vc, animated: false, completion: nil)
    }
    
    
    
    func tapAction(index: Int) {
        switch index {
        case 0:
            let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyBoard.instantiateViewController(withIdentifier: "PatientProfileVc") as! PatientProfileVc
            self.navigationController?.pushViewController(vc, animated: true)
        case 1:
            let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyBoard.instantiateViewController(withIdentifier: "PatientWeekListVc") as! PatientWeekListVc
            self.navigationController?.pushViewController(vc, animated: true)
        case 2:
            let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyBoard.instantiateViewController(withIdentifier: "PatientDailyProgress") as! PatientDailyProgress
            vc.patientID = UserDefaultsManager.shared.getUserId() ?? ""
            self.navigationController?.pushViewController(vc, animated: true)
        case 3:
            let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyBoard.instantiateViewController(withIdentifier: "EducationalVc") as! EducationalVc
            self.navigationController?.pushViewController(vc, animated: true)
            
        case 4:
            guard let whatsappURL = URL(string: "https://api.whatsapp.com/send?phone=\(9876543210)") else {
                // Handle invalid URL
                return
            }
            
            if UIApplication.shared.canOpenURL(whatsappURL) {
                UIApplication.shared.open(whatsappURL, options: [:], completionHandler: nil)
            } else {
                let alertController = UIAlertController(title: "Error", message: "WhatsApp is not installed on your device.", preferredStyle: .alert)
                let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
                alertController.addAction(okAction)
                presentingViewController?.present(alertController, animated: true, completion: nil)
            }

        case 5:
            let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyBoard.instantiateViewController(withIdentifier: "loginVC") as! loginVC
            self.navigationController?.pushViewController(vc, animated: true)
        default:
            print("out of index")
        }
    }
    
    
    

  }




extension CandidateHomeVc: UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 3
    }

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        if section == 0 {
            return 1
        }else if section == 1 {
            return 1
        }else {
            return 1
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if indexPath.section == 0 {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CandidateHomeBannerCVC", for: indexPath) as! CandidateHomeBannerCVC
            
            return cell
        }
        else if indexPath.section == 1 {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CandidateHomePerfCVC", for: indexPath) as! CandidateHomePerfCVC
            
            return cell
        }
        else if indexPath.section == 2 {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CandidateHomeCategoriesCVC", for: indexPath) as! CandidateHomeCategoriesCVC
            cell.tapExercise = {
                let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                let vc = storyBoard.instantiateViewController(withIdentifier: "PatientWeekListVc") as! PatientWeekListVc
                self.navigationController?.pushViewController(vc, animated: true)
            }
            cell.tapEducation = {
                let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                let vc = storyBoard.instantiateViewController(withIdentifier: "EducationalVc") as! EducationalVc
                self.navigationController?.pushViewController(vc, animated: true)
            }
            cell.tapProgress = {
                let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                let vc = storyBoard.instantiateViewController(withIdentifier: "PatientDailyProgress") as! PatientDailyProgress
                vc.patientID = UserDefaultsManager.shared.getUserId() ?? ""
                self.navigationController?.pushViewController(vc, animated: true)
            }
            cell.tapChat = {
                self.openWhatsAppChat(with: "9876543210", presentingViewController: self)
            }
            return cell
        }
        return UICollectionViewCell()
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if indexPath.section == 1 {
            return CGSize(width: collectionView.frame.width, height: 250.0)
        }else{
            return CGSize(width: collectionView.frame.width, height: 200.0)

        }
        }
    
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
          let sectionInsets = UIEdgeInsets(top: 10, left: 10, bottom: 20, right: 10)
          return sectionInsets
      }

}
