//
//  ViewVideoVc.swift
//  FIEXFIT
//
//  Created by SAIL on 19/02/24.
//

import UIKit
import AVKit
import AVFoundation
import ReplayKit

class ViewVideoVc: BasicVC {

    @IBOutlet weak var videoView: UIView!
    @IBOutlet weak var titleView: UIView!
    @IBOutlet weak var cameraView: UIView!
    @IBOutlet weak var screenRecordingButton: UIButton!

    var captureSession: AVCaptureSession!
    var previewLayer: AVCaptureVideoPreviewLayer!
    var player: AVPlayer?
    var playerLayer: AVPlayerLayer?
    var videoData = ""
    let apiUrl = APIList().BASE_URL
    var isPlaying = true
    var videoDetailsData = [videoDetails]()
    var videoURLName: URL?
    var week = ""

    override func viewDidLoad() {
        super.viewDidLoad()
        print("videoDetailsData :\(videoDetailsData.first?.videoUrl ?? "")")
        if videoDetailsData.first?.videoUrl == "" {
            playVideo(with: videoData)
        } else {
            playVideo(with: "\(apiUrl + (videoDetailsData.first?.videoUrl ?? ""))")
        }
        setupPlaybackControls()
        player?.addObserver(self, forKeyPath: "status", options: [.new, .initial], context: nil)
        initializeCamera()
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        if captureSession.isRunning {
            captureSession.stopRunning()
        }
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        playerLayer?.frame = videoView.bounds
        if let cameraView = cameraView {
            previewLayer.frame = cameraView.bounds
        } else {
            print("cameraView is nil")
        }

    }

    deinit {
        if let player = player, let playerLayer = playerLayer {
            player.removeObserver(self, forKeyPath: #keyPath(AVPlayer.status))
            playerLayer.removeFromSuperlayer()
        }
    }

    func initializeCamera() {
        captureSession = AVCaptureSession()
        captureSession.sessionPreset = .medium

        guard let frontCamera = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .front) else {
            showAlert(message: "Front camera not found")
            return
        }

        do {
            let input = try AVCaptureDeviceInput(device: frontCamera)

            if captureSession.canAddInput(input) {
                captureSession.addInput(input)
            }
            previewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
            previewLayer.videoGravity = .resizeAspectFill
            previewLayer.frame = cameraView.bounds
            cameraView.layer.addSublayer(previewLayer)

            DispatchQueue.global(qos: .background).async {
                self.captureSession.startRunning()
            }
        } catch {
            showAlert(message: error.localizedDescription)
        }
    }

    @IBAction func backBtn(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }

    @IBAction func screenRecordingButtonTapped(_ sender: UIButton) {
        if #available(iOS 9.0, *) {
            if RPScreenRecorder.shared().isAvailable {
                if !RPScreenRecorder.shared().isRecording {
                    startRecording()
                } else {
                    stopRecording()
                }
            }
        }
    }

    func startRecording() {
        if #available(iOS 9.0, *) {
            if RPScreenRecorder.shared().isAvailable {
                RPScreenRecorder.shared().startRecording { [weak self] error in
                    if let error = error {
                        self?.showAlert(message: "Error starting recording: \(error.localizedDescription)")
                    } else {
                        DispatchQueue.main.async {
                            self?.updateScreenRecordingButtonUI(isRecording: true)
                        }
                    }
                }
            }
        }
    }

    func stopRecording() {
        if #available(iOS 9.0, *) {
            RPScreenRecorder.shared().stopRecording { [weak self] (previewViewController, error) in
                if let error = error {
                    self?.showAlert(message: "Error stopping recording: \(error.localizedDescription)")
                } else if let previewViewController = previewViewController {
                    previewViewController.modalPresentationStyle = .fullScreen
                    previewViewController.previewControllerDelegate = self
                    self?.stopVideo()
                    self?.present(previewViewController, animated: true, completion: nil)
                }
            }
        }
    }
    private func stopVideo() {
        player?.pause()
        playerLayer?.removeFromSuperlayer()
        player = nil
        playerLayer = nil
    }

    func setupPlaybackControls() {
        let playPauseButton = UIButton(type: .custom)
        let playImage = UIImage(named: "PauseImage")
        playPauseButton.setImage(playImage, for: .normal)
        playPauseButton.addTarget(self, action: #selector(playPauseButtonTapped), for: .touchUpInside)
        videoView.addSubview(playPauseButton)
        playPauseButton.translatesAutoresizingMaskIntoConstraints = false
        playPauseButton.centerXAnchor.constraint(equalTo: videoView.centerXAnchor).isActive = true
        playPauseButton.bottomAnchor.constraint(equalTo: videoView.bottomAnchor, constant: -20).isActive = true

        let forwardButton = UIButton(type: .custom)
        let forwardImage = UIImage(named: "ForwordImage")
        forwardButton.setImage(forwardImage, for: .normal)
        forwardButton.addTarget(self, action: #selector(forwardButtonTapped), for: .touchUpInside)
        videoView.addSubview(forwardButton)
        forwardButton.translatesAutoresizingMaskIntoConstraints = false
        forwardButton.leadingAnchor.constraint(equalTo: playPauseButton.trailingAnchor, constant: 20).isActive = true
        forwardButton.centerYAnchor.constraint(equalTo: playPauseButton.centerYAnchor).isActive = true

        let backwardButton = UIButton(type: .custom)
        let backwardImage = UIImage(named: "BackwordImage")
        backwardButton.setImage(backwardImage, for: .normal)
        backwardButton.addTarget(self, action: #selector(backwardButtonTapped), for: .touchUpInside)
        videoView.addSubview(backwardButton)
        backwardButton.translatesAutoresizingMaskIntoConstraints = false
        backwardButton.trailingAnchor.constraint(equalTo: playPauseButton.leadingAnchor, constant: -20).isActive = true
        backwardButton.centerYAnchor.constraint(equalTo: playPauseButton.centerYAnchor).isActive = true

        let spacerView = UIView()
        spacerView.backgroundColor = .white
        videoView.addSubview(spacerView)
        spacerView.translatesAutoresizingMaskIntoConstraints = false
        spacerView.leadingAnchor.constraint(equalTo: videoView.trailingAnchor, constant: 20).isActive = true
        spacerView.trailingAnchor.constraint(equalTo: videoView.leadingAnchor, constant: 20).isActive = true
        spacerView.centerYAnchor.constraint(equalTo: playPauseButton.centerYAnchor).isActive = true
    }

    @objc func playPauseButtonTapped() {
        isPlaying = !isPlaying
        let playPauseButton = videoView.subviews.first { $0 is UIButton } as? UIButton
        if isPlaying {
            let pauseImage = UIImage(named: "PauseImage")
            playPauseButton?.setImage(pauseImage, for: .normal)
            player?.play()
        } else {
            let playImage = UIImage(named: "PlayImage")
            playPauseButton?.setImage(playImage, for: .normal)
            player?.pause()
        }
    }

    @objc func forwardButtonTapped() {
        if let player = player {
            player.seek(to: CMTimeAdd(player.currentTime(), CMTime(seconds: 10, preferredTimescale: 1)))
        }
    }

    @objc func backwardButtonTapped() {
        if let player = player {
            player.seek(to: CMTimeSubtract(player.currentTime(), CMTime(seconds: 10, preferredTimescale: 1)))
        }
    }

    func playVideo(with url: String) {
        guard let videoURL = URL(string: url) else {
            showAlert(message: "Invalid video URL")
            return
        }

        player = AVPlayer(url: videoURL)

        guard let player = player else {
            showAlert(message: "Failed to initialize AVPlayer")
            return
        }

        playerLayer?.removeFromSuperlayer()

        playerLayer = AVPlayerLayer(player: player)
        playerLayer?.frame = videoView.bounds
        playerLayer?.videoGravity = .resizeAspect
        videoView.layer.addSublayer(playerLayer!)

        player.play()
    }

    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        if keyPath == "status", let player = object as? AVPlayer {
            if player.status == .failed {
                showAlert(message: "Player failed to load the video")
            }
        }
    }

    private func showAlert(message: String) {
        let alertController = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alertController, animated: true, completion: nil)
    }

    private func updateScreenRecordingButtonUI(isRecording: Bool) {
        let title = isRecording ? "Stop Recording" : "Start Recording"
        let imageName = isRecording ? "StopImage" : "PlayImage"
        screenRecordingButton.setTitle(title, for: .normal)
        screenRecordingButton.setImage(UIImage(named: imageName), for: .normal)
    }
}
extension ViewVideoVc: RPPreviewViewControllerDelegate {
    func previewController(_ previewController: RPPreviewViewController, didFinishWithActivityTypes activityTypes: Set<String>) {
        if activityTypes.contains(UIActivity.ActivityType.saveToCameraRoll.rawValue) {
            // Screen recording was saved
            let alertController = UIAlertController(title: "Video Saved", message: "The screen recording was saved successfully.", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: { _ in
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "PatientVideoUploadVc") as! PatientVideoUploadVc
                vc.week = self.week
                vc.videoTitle = self.videoDetailsData.first?.videoName ?? ""
                self.navigationController?.pushViewController(vc, animated: true)
            }))
            previewController.dismiss(animated: true) {
                self.present(alertController, animated: true, completion: nil)
            }
        } else {
            // Screen recording was not saved
            previewController.dismiss(animated: true) {
                self.navigationController?.popViewController(animated: true)
            }
        }
    }
}
