//
//  DocViewProfileVc.swift
//  FIEXFIT
//
//  Created by Saranya Ravi on 09/11/23.
//

import UIKit

class DocViewProfileVc: BasicVC {
    
    @IBOutlet weak var idView: UIView!
    @IBOutlet weak var nameView: UIView!
    @IBOutlet weak var ageView: UIView!
    @IBOutlet weak var genderView: UIView!
    @IBOutlet weak var idField: UITextField!
    @IBOutlet weak var nameField: UITextField!
    @IBOutlet weak var ageField: UITextField!
    @IBOutlet weak var genderField: UITextField!
    @IBOutlet weak var profileImage: UIImageView!
    @IBOutlet weak var saveBtn: UIButton!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        idView.layer.cornerRadius = 10
        nameView.layer.cornerRadius = 10
        ageView.layer.cornerRadius = 10
        genderView.layer.cornerRadius = 10
        saveBtn.layer.cornerRadius = 10
   
        doctorProfile()
    }
    
    
    func doctorProfile() {
        
        let doctorId = UserDefaultsManager.shared.getUserId()
        
            let apiURL = APIList().urlString(url:.doctorProfile)
            
            let formData = ["doctor_id" : "\(doctorId ?? "")"]
        
            APIHandler().postAPIValues(type: DoctorProfile.self, apiUrl: apiURL, method: "POST", formData: formData) {  result in
                switch result {
                case .success(let data):
                    DispatchQueue.main.async { [self] in
                    if data.success == true{
                        self.nameField.text = "\(data.data.name)"
                        self.ageField.text = "\(data.data.age)"
                        self.genderField.text = "\(data.data.gender)"
                        self.idField.text = "\(data.data.doctorID)"
                        
                     }
                    else if data.success == false{
                           showToast(data.message )
                        }
                        self.stopIndicator()
                    }
                    case .failure(let error):
                    print(error)
                    DispatchQueue.main.async {
                        self.stopIndicator()
                        self.showAlert(title: "Failure", message: "Something Went Wrong", okActionHandler: {})
                    }
                }
            }
        }
    
    
    func doctorProfileUpdate() {
        
         let apiURL = APIList().urlString(url:.DoctorUpdateProfile)
            
        let formData = ["username" : "Doctor",
                        "doctor_id" : idField.text ?? "",
                        "name" : nameField.text ?? "",
                        "age":ageField.text ?? "",
                        "gender" : genderField.text ?? ""           
            ]
        
            APIHandler().postAPIValues(type: DoctorProfileUpdateModal.self, apiUrl: apiURL, method: "POST", formData: formData) {  result in
                switch result {
                case .success(let data):
                    DispatchQueue.main.async { [self] in
                    if data.success == true{
                        self.navigationController?.popViewController(animated: false)
                        
                     }
                    else if data.success == false{
                           showToast(data.message )
                        }
                        self.stopIndicator()
                    }
                    case .failure(let error):
                    print(error)
                    DispatchQueue.main.async {
                        self.stopIndicator()
                        self.showAlert(title: "Failure", message: "Something Went Wrong", okActionHandler: {})
                    }
                }
            }
        }
    
    @IBAction func save(_ sender: Any) {
        
        doctorProfileUpdate()
        
    }
    
    
    
    @IBAction func backTap(_ sender: Any) {
        
        self.navigationController?.popViewController(animated: false)
    }
    
}
