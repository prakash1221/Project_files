//
//  SideMenuVc.swift
//  FIEXFIT
//
//  Created by Saranya Ravi on 07/11/23.
//

import UIKit


struct Menu {
    let simage : UIImage?
    let sname : String?
}
class SideMenuVc: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    var menuList : [Menu] = []
    
    
    
    
    @IBOutlet weak var sidemenuTable: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        sidemenuTable.delegate = self
        sidemenuTable.dataSource = self
        sidemenuTable.separatorStyle = .none
        menuList.append(Menu(simage: UIImage(named: "Home"), sname: "Home"))
        menuList.append(Menu(simage: UIImage(named: "Edit"), sname: "Profile"))
        menuList.append(Menu(simage: UIImage(named: "Friends"), sname: "Graph monitor"))
        menuList.append(Menu(simage: UIImage(named: "Friends"), sname: "Logout"))
        sidemenuTable.reloadData()
        // Do any additional setup after loading the view.
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return menuList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MenuTVC", for: indexPath) as! MenuTVC
        let dict = menuList[indexPath.row]
        cell.sidemenuImage.image = dict.simage
        cell.sidemenuName.text = dict.sname
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200.0
    }

    

}
