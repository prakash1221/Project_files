//
//  ShowVideoVC.swift
//  FIEXFIT
//
//  Created by SAIL on 24/02/24.
//

import UIKit
import AVKit
import AVFoundation

class ShowVideoVC: UIViewController {
    @IBOutlet weak var videoView: UIView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var backButton: UIButton!
    
    
    var player: AVPlayer?
    var playerLayer: AVPlayerLayer?
    var name = ""
    var descriptionName = ""
    var videoData = ""
    var isPlaying = true
    
    override func viewDidLoad() {
        super.viewDidLoad()
        nameLabel.text = name
//        descriptionLabel.text = descriptionName
        print(videoData)
        playVideo(with: videoData)
//        setupPlaybackControls()
        player?.addObserver(self, forKeyPath: "status", options: [.new, .initial], context: nil)
    }
    @IBAction func backBtn(_ sender: Any) {
        
        self.navigationController?.popViewController(animated: true)
    }
//    func setupPlaybackControls() {
//        
//        let playPauseButton = UIButton(type: .custom)
//        let playImage = UIImage(named: "PauseImage")
//        playPauseButton.setImage(playImage, for: .normal)
//        playPauseButton.addTarget(self, action: #selector(playPauseButtonTapped), for: .touchUpInside)
//        videoView.addSubview(playPauseButton)
//        playPauseButton.translatesAutoresizingMaskIntoConstraints = false
//        playPauseButton.centerXAnchor.constraint(equalTo: videoView.centerXAnchor).isActive = true
//        playPauseButton.bottomAnchor.constraint(equalTo: videoView.bottomAnchor, constant: -20).isActive = true
//        
//        let forwardButton = UIButton(type: .custom)
//        let forwardImage = UIImage(named: "ForwordImage")
//        forwardButton.setImage(forwardImage, for: .normal)
//        forwardButton.addTarget(self, action: #selector(forwardButtonTapped), for: .touchUpInside)
//        videoView.addSubview(forwardButton)
//        forwardButton.translatesAutoresizingMaskIntoConstraints = false
//        forwardButton.leadingAnchor.constraint(equalTo: playPauseButton.trailingAnchor, constant: 20).isActive = true
//        forwardButton.centerYAnchor.constraint(equalTo: playPauseButton.centerYAnchor).isActive = true
//        
//        let backwardButton = UIButton(type: .custom)
//        let backwardImage = UIImage(named: "BackwordImage")
//        backwardButton.setImage(backwardImage, for: .normal)
//        backwardButton.addTarget(self, action: #selector(backwardButtonTapped), for: .touchUpInside)
//        videoView.addSubview(backwardButton)
//        backwardButton.translatesAutoresizingMaskIntoConstraints = false
//        backwardButton.trailingAnchor.constraint(equalTo: playPauseButton.leadingAnchor, constant: -20).isActive = true
//        backwardButton.centerYAnchor.constraint(equalTo: playPauseButton.centerYAnchor).isActive = true
//        
//        let spacerView = UIView()
//        spacerView.backgroundColor = .white
//        videoView.addSubview(spacerView)
//        spacerView.translatesAutoresizingMaskIntoConstraints = false
//        spacerView.leadingAnchor.constraint(equalTo: videoView.trailingAnchor, constant: 20).isActive = true
//        spacerView.trailingAnchor.constraint(equalTo: videoView.leadingAnchor, constant: 20).isActive = true
//        spacerView.centerYAnchor.constraint(equalTo: playPauseButton.centerYAnchor).isActive = true
//    }
    
//    @objc func playPauseButtonTapped() {
//        isPlaying = !isPlaying
//        
//        let playPauseButton = videoView.subviews.first { $0 is UIButton } as? UIButton
//        
//        if isPlaying {
//            // Change image to pauseImage when video is playing
//            let pauseImage = UIImage(named: "PauseImage")
//            playPauseButton?.setImage(pauseImage, for: .normal)
//            // Start video playback logic
//            player?.play()
//        } else {
//            // Change image to playImage when video is paused
//            let playImage = UIImage(named: "PlayImage")
//            playPauseButton?.setImage(playImage, for: .normal)
//            // Pause video playback logic
//            player?.pause()
//        }
//    }
    
//    @objc func forwardButtonTapped() {
//        if let player = player {
//            player.seek(to: CMTimeAdd(player.currentTime(), CMTime(seconds: 10, preferredTimescale: 1)))
//        }
//    }
//    
//    @objc func backwardButtonTapped() {
//        if let player = player {
//            player.seek(to: CMTimeSubtract(player.currentTime(), CMTime(seconds: 10, preferredTimescale: 1)))
//        }
//    }
//    
//    func playVideo(with url: String) {
//        guard let videoURL = URL(string: url) else {
//            print("Invalid video URL")
//            return
//        }
//        
//        player = AVPlayer(url: videoURL)
//        
//        guard let player = player else {
//            print("Failed to initialize AVPlayer")
//            return
//        }
//        
//        playerLayer?.removeFromSuperlayer()
//        
//        playerLayer = AVPlayerLayer(player: player)
//        playerLayer?.frame = videoView.bounds
//        playerLayer?.videoGravity = .resizeAspect
//        
//        videoView.layer.addSublayer(playerLayer!)
//        
//        player.play()
//    }
    
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        if keyPath == "status", let player = object as? AVPlayer {
            if player.status == .failed {
                print("Player failed to load the video")
            }
        }
    }
    
    deinit {
        if let player = player, let playerLayer = playerLayer {
            player.removeObserver(self, forKeyPath: #keyPath(AVPlayer.status))
            playerLayer.removeFromSuperlayer()
        }
    }
}
extension ShowVideoVC{
    func playVideo(with url: String) {
        
        let base = url
        print("base :\(base)")

           guard let videoURL = URL(string: "\(base)") else {
               print("Invalid video URL")
             
               return
           }
          print("videoURL : \(videoURL)")
           player = AVPlayer(url: videoURL)
           
           guard let player = player else {
               //  print("Failed to initialize AVPlayer")
               return
           }
           
           let playerViewController = AVPlayerViewController()
           playerViewController.player = player
           playerViewController.entersFullScreenWhenPlaybackBegins = false
           playerViewController.allowsPictureInPicturePlayback = false
           
           addChild(playerViewController)
        videoView.addSubview(playerViewController.view)
           playerViewController.view.frame = videoView.bounds
           playerViewController.didMove(toParent: self)
           
           // Add observer for player status
           player.addObserver(self, forKeyPath: #keyPath(AVPlayer.status), options: .new, context: nil)
       }

}
