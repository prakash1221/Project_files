//
//  SlideMenuVc.swift
//  FIEXFIT
//
//  Created by Saranya Ravi on 13/12/23.
//

import UIKit


protocol SlideMenuProto {
    
    func onSideMenu( menuNo : Int)
}


class SlideMenuVc: UIViewController {
    
    @IBOutlet weak var bglayoutView: UIView!
    
    
    @IBOutlet weak var slideView: UIView!
    
    
    @IBOutlet weak var cancelBtn: UIButton!
    
    var sideDelegate : SlideMenuProto!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        slideView.layer.cornerRadius = 10
        cancelBtn.layer.cornerRadius = 10
        
    }
//    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
//        let touch = touches.first
//        if touch?.view == self.bglayoutView {
//            self.dismiss(animated: false, completion: nil)
//        }
//    }
    @IBAction func onHome(_ sender: UIButton) {
        sideDelegate.onSideMenu(menuNo: 1)
        
    }
    
    @IBAction func onProfile(_ sender: UIButton) {
        sideDelegate.onSideMenu(menuNo: 2)
        self.dismiss(animated: false, completion: nil)
    }
    
    
    @IBAction func onGraph(_ sender: UIButton) {
        sideDelegate.onSideMenu(menuNo: 3)
        self.dismiss(animated: false, completion: nil)
    }
    
    @IBAction func onAddCandidate(_ sender: UIButton) {
        sideDelegate.onSideMenu(menuNo: 4)
        self.dismiss(animated: false, completion: nil)
    }
    
    @IBAction func onAddVideos(_ sender: UIButton) {
        sideDelegate.onSideMenu(menuNo: 5)
        self.dismiss(animated: false, completion: nil)
    }
    @IBAction func showvideosButton(_ sender: UIButton) {
        sideDelegate.onSideMenu(menuNo: 6)
        self.dismiss(animated: false, completion: nil)
    } 
    @IBAction func onLogout(_ sender: UIButton) {
        sideDelegate.onSideMenu(menuNo: 7)
        self.dismiss(animated: false, completion: nil)
    }
    
    @IBAction func cancelTapped(_ sender: Any) {
        self.dismiss(animated: false, completion: nil)
    }
    
   
}
