//
//  VideoCaptureViewController.swift
//  FIEXFIT
//
//  Created by SAIL on 26/12/23.
//
import UIKit
import AVFoundation

class VideoCaptureViewController: UIViewController {

    var captureSession: AVCaptureSession?
    var videoPreviewLayer: AVCaptureVideoPreviewLayer?
    var movieOutput: AVCaptureMovieFileOutput?
    var outputURL: URL?

    @IBOutlet weak var previewView: UIView!
    @IBOutlet weak var startStopButton: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
        setupCaptureSession()
        setupPreviewLayer()
        updateUIForRecording(false)
    }

    func setupCaptureSession() {
        captureSession = AVCaptureSession()

        guard let captureSession = captureSession else { return }

        // Configure the input device (front camera)
        if let frontCamera = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .front) {
            do {
                let input = try AVCaptureDeviceInput(device: frontCamera)
                if captureSession.canAddInput(input) {
                    captureSession.addInput(input)
                }
            } catch let error {
                print("Error setting up front camera input: \(error.localizedDescription)")
                return
            }
        } else {
            print("Front camera not available.")
            return
        }

        movieOutput = AVCaptureMovieFileOutput()

        if let movieOutput = movieOutput, captureSession.canAddOutput(movieOutput) {
            captureSession.addOutput(movieOutput)
        }

        captureSession.startRunning()
    }


    func setupPreviewLayer() {
        guard let captureSession = captureSession else { return }

        videoPreviewLayer = AVCaptureVideoPreviewLayer(session: captureSession)

        if let videoPreviewLayer = videoPreviewLayer {
            videoPreviewLayer.videoGravity = .resizeAspectFill
            videoPreviewLayer.frame = previewView.layer.bounds
            previewView.layer.addSublayer(videoPreviewLayer)
        }
    }

    func updateUIForRecording(_ isRecording: Bool) {
        startStopButton.setTitle(isRecording ? "Stop Recording" : "Start Recording", for: .normal)
        startStopButton.isEnabled = !isRecording
        // Additional UI updates can be added here
    }

    @IBAction func startStopButtonPressed(_ sender: UIButton) {
        guard let movieOutput = movieOutput else { return }

        if !movieOutput.isRecording {
            startRecording()
        } else {
            stopRecording()
        }
    }

    func startRecording() {
        guard let movieOutput = movieOutput else { return }

        let documentsURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        outputURL = documentsURL.appendingPathComponent(UUID().uuidString).appendingPathExtension("mov")

        movieOutput.startRecording(to: outputURL!, recordingDelegate: self)
        updateUIForRecording(true)
    }

    func stopRecording() {
        guard let movieOutput = movieOutput else { return }

        movieOutput.stopRecording()
        updateUIForRecording(false)
    }
}

extension VideoCaptureViewController: AVCaptureFileOutputRecordingDelegate {
    func fileOutput(_ output: AVCaptureFileOutput, didStartRecordingTo fileURL: URL, from connections: [AVCaptureConnection]) {
        // Handle recording start
        print("Recording started: \(fileURL)")
    }

    func fileOutput(_ output: AVCaptureFileOutput, didFinishRecordingTo outputFileURL: URL, from connections: [AVCaptureConnection], error: Error?) {
        // Handle recording finish
        if let error = error {
            print("Recording failed: \(error.localizedDescription)")
        } else {
            print("Recording finished: \(outputFileURL)")
        }
    }
}
