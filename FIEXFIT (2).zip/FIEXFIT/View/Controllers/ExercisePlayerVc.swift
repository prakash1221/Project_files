//
//  ExercisePlayerVc.swift
//  FIEXFIT
//
//  Created by Saranya Ravi on 29/11/23.
//

import UIKit
import AVKit

class ExercisePlayerVc: UIViewController {

    @IBOutlet weak var docExVideo: UIView!
    
    @IBOutlet weak var patientExVideo: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    func onPlayVideo() {
//        let url = Bundle.main.url(forResource: " ", withExtension: "mp4")
//        let avPlayer = AVPlayer(url : url)
//        let avController = AVPlayerViewController()
//        avController.player = avPlayer
//        present(avController, animated: true,completion : nil)
    }
    func onRecord() {
        
    }
    

}
