import UIKit

class PatientDailyProgress: BasicVC {

    @IBOutlet weak var tableview: UITableView! {
        didSet {
            tableview.delegate = self
            tableview.dataSource = self
            tableview.allowsMultipleSelection = true // Enable multiple selection
        }
    }
    var type: String = ""
    var exerciseListData: [String] = []
    var stabilityExercises: [String] = []
    var mobilityExercises: [String] = []
    var proprioceptionExercises: [String] = []
    var patientVideoTitles : [String] = []
    var connectionType = "Online"
    var patientID =  ""
    override func viewDidLoad() {
        super.viewDidLoad()
        tableview.register(UINib.init(nibName: "SessionListTVC", bundle: nil), forCellReuseIdentifier: "SessionListTVC")
        tableview.isHidden = true
    }

    @IBAction func onBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }

    @IBAction func stabilityButton(_ sender: Any) {
        tableview.isHidden = !tableview.isHidden
        if !tableview.isHidden {
            type = "stability"
            getApi(type: type)
        }
    }

    @IBAction func mobilityButton(_ sender: Any) {
        tableview.isHidden = !tableview.isHidden
        if !tableview.isHidden {
            type = "mobility"
            getApi(type: type)
        }
    }

    @IBAction func proButton(_ sender: Any) {
        tableview.isHidden = !tableview.isHidden
        if !tableview.isHidden {
            type = "proprioception"
            getApi(type: type)
        }
    }

    @IBAction func nextButton(_ sender: Any) {
        // Print the selected exercise data
        print("Stability Exercises: \(stabilityExercises)")
        print("Mobility Exercises: \(mobilityExercises)")
        print("Proprioception Exercises: \(proprioceptionExercises)")

        // Navigate to the next view controller
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "PatientFeedbackAndResponseVc") as! PatientFeedbackAndResponseVc
        vc.stabilityExercises = stabilityExercises
        vc.mobilityExercises = mobilityExercises
        vc.proprioceptionExercises = proprioceptionExercises
        vc.type = connectionType
        vc.typeData = patientID
        self.navigationController?.pushViewController(vc, animated: true)
    }

}

extension PatientDailyProgress {
    func getApi(type : String) {
        if connectionType == "Online"{
            let apiURL = APIList().urlString(url:.patientVideoListApi)
            let formData = ["user_id" : patientID,
                            "category" : type]
            APIHandler().postAPIValues(type: PatientVideoListModel.self, apiUrl: apiURL, method: "POST", formData: formData) {  result in
                switch result {
                case .success(let data):
                    DispatchQueue.main.async { [self] in
                        if data.status {
                            patientVideoTitles = Array(Set(data.data.flatMap { $0.selectedTitles }))
                            tableview.reloadData()
                        } else {
                            showToast(data.message)
                        }
                        stopIndicator()
                    }
                case .failure(let error):
                    print(error)
                    DispatchQueue.main.async { [self] in
                        stopIndicator()
                        showAlert(title: "Failure", message: "Something Went Wrong", okActionHandler: {})
                    }
                }
            }
        }else {
            let apiURL = APIList().urlString(url:.DisplayVideoTitleApi) + type
           
            APIHandler().getAPIValues(type: DisplayVideoListModel.self, apiUrl: apiURL, method: "GET") {  result in
                switch result {
                case .success(let data):
                    DispatchQueue.main.async { [self] in
                        if data.status {
                            patientVideoTitles = data.data
                            tableview.reloadData()
                        } else {
                            showToast(data.message)
                        }
                        stopIndicator()
                    }
                case .failure(let error):
                    print(error)
                    DispatchQueue.main.async { [self] in
                        stopIndicator()
                        showAlert(title: "Failure", message: "Something Went Wrong", okActionHandler: {})
                    }
                }
            }
        }
       
    }

}

extension PatientDailyProgress: UITableViewDelegate, UITableViewDataSource {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return patientVideoTitles.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableview.dequeueReusableCell(withIdentifier: "SessionListTVC", for: indexPath) as! SessionListTVC
        let exercise = patientVideoTitles[indexPath.row]
        cell.sessionLbl.text = exercise
        cell.selectionStyle = .none
        switch type {
        case "stability":
            cell.accessoryType = stabilityExercises.contains(exercise) ? .checkmark : .none
        case "mobility":
            cell.accessoryType = mobilityExercises.contains(exercise) ? .checkmark : .none
        case "proprioception":
            cell.accessoryType = proprioceptionExercises.contains(exercise) ? .checkmark : .none
        default:
            cell.accessoryType = .none
        }

        return cell
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard let cell = tableView.cellForRow(at: indexPath) else { return }
        cell.accessoryType = .checkmark
        let selectedExercise = patientVideoTitles[indexPath.row]
        switch type {
        case "stability":
            if !stabilityExercises.contains(selectedExercise) {
                stabilityExercises.append(selectedExercise)
            }
        case "mobility":
            if !mobilityExercises.contains(selectedExercise) {
                mobilityExercises.append(selectedExercise)
            }
        case "proprioception":
            if !proprioceptionExercises.contains(selectedExercise) {
                proprioceptionExercises.append(selectedExercise)
            }
        default:
            break
        }
    }

    func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
        guard let cell = tableView.cellForRow(at: indexPath) else { return }
        cell.accessoryType = .none
        let deselectedExercise = patientVideoTitles[indexPath.row]
        switch type {
        case "stability":
            if let index = stabilityExercises.firstIndex(of: deselectedExercise) {
                stabilityExercises.remove(at: index)
            }
        case "mobility":
            if let index = mobilityExercises.firstIndex(of: deselectedExercise) {
                mobilityExercises.remove(at: index)
            }
        case "proprioception":
            if let index = proprioceptionExercises.firstIndex(of: deselectedExercise) {
                proprioceptionExercises.remove(at: index)
            }
        default:
            break
        }
    }
}
