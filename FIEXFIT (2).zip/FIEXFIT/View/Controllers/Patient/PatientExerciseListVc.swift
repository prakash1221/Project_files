//
//  PatientExerciseListVc.swift
//  FIEXFIT
//
//  Created by SAIL on 10/02/24.
//

import UIKit
struct videoDetails {
    var videoName : String
    var videoUrl : String
}
class PatientExerciseListVc: BasicVC ,UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var exerciseTable: UITableView! {
        didSet {
            exerciseTable.delegate = self
            exerciseTable.dataSource = self
        }
    }
    var category : String = ""
    var weeksData: String = ""
    var patientVideoTitles: [PatientVideoDisplayData] = []
    var videoData = [videoDetails]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let nib = UINib(nibName: "ExerciseListTVC", bundle: nil)
        exerciseTable.register(nib, forCellReuseIdentifier: "ExerciseListTVC")
        getApi()
    }
    
    @IBAction func backTap(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        guard section < patientVideoTitles.count else {
            return 0
        }
        return patientVideoTitles[section].selectedTitles.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = exerciseTable.dequeueReusableCell(withIdentifier: "ExerciseListTVC", for: indexPath) as! ExerciseListTVC
        let data = patientVideoTitles[indexPath.section].selectedTitles[indexPath.row]
        cell.videoTitleLabel.text = data

        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "PatientInfoPageVc") as! PatientInfoPageVc
        let selectedData = patientVideoTitles[indexPath.section].selectedTitles[indexPath.row]
        let selectedPath = patientVideoTitles[indexPath.section].selectedPath[indexPath.row]
         videoData.append(videoDetails(videoName: selectedData, videoUrl: selectedPath))
        vc.videoData = videoData
        vc.week = weeksData
        print("videoData :\(videoData)")
        self.navigationController?.pushViewController(vc, animated: true)
    }
     func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }

    

}
extension PatientExerciseListVc {
    func getApi() {
        let patientID = UserDefaultsManager.shared.getUserId() ?? ""
        let apiURL = APIList().urlString(url:.patientVideoDisplay) + patientID + "&week=\(weeksData)&category=\(category)"
        
        APIHandler().getAPIValues(type: PatientVideoDisplayModel.self, apiUrl: apiURL, method: "GET") {  result in
            switch result {
            case .success(let data):
                DispatchQueue.main.async { [self] in
                    if data.status {
                        patientVideoTitles = data.data
                        exerciseTable.reloadData()
                    } else {
                        showToast(data.message)
                    }
                    stopIndicator()
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async { [self] in
                    stopIndicator()
                    showAlert(title: "Failure", message: "Something Went Wrong", okActionHandler: {})
                }
            }
        }
    }

}
