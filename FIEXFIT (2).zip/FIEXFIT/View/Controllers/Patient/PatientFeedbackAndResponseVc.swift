//
//  PatientFeedbackAndResponseVc.swift
//  FIEXFIT
//
//  Created by SAIL on 12/02/24.
//
import UIKit

class PatientFeedbackAndResponseVc: BasicVC {

    @IBOutlet var qOneButtons: [UIButton]!
    @IBOutlet var qTwoButtons: [UIButton]!
    @IBOutlet weak var noButton: UIButton!
    @IBOutlet weak var yesButton: UIButton!
    
    var stabilityExercises: [String] = []
    var mobilityExercises: [String] = []
    var proprioceptionExercises: [String] = []
    var type = "Online"
    var answerVar = ""
    var answerOneVar = ""
    var answerTwoVar = ""
    var typeData = ""
    var patientID = UserDefaultsManager.shared.getUserId() ?? ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if type == "Online"{
            patientID = UserDefaultsManager.shared.getUserId() ?? ""
        }else{
             patientID = typeData

        }
        yesButton.tag = 1
        noButton.tag = 2
        
        setupButtonActions(for: qOneButtons)
        setupButtonActions(for: qTwoButtons)
    }
    @IBAction func ButtonAct(_ sender: UIButton) {
           // Check which button was tapped based on its tag
           switch sender.tag {
           case 1:
               // "Yes" button was tapped
               updateButtonImages(selectedButton: yesButton, deselectedButton: noButton)
               answerVar = "Yes"
               print("Yes clicked")
           case 2:
               // "No" button was tapped
               updateButtonImages(selectedButton: noButton, deselectedButton: yesButton)
               answerVar = "No"

               print("No clicked")
           default:
               break
           }
       }
       
    func updateButtonImages(selectedButton: UIButton, deselectedButton: UIButton) {
        selectedButton.setImage(UIImage(systemName: "checkmark.circle.fill")?.withTintColor(.orange), for: .normal)
           deselectedButton.setImage(UIImage(named: "Ellipse sixtyone"), for: .normal)
       }
    func setupButtonActions(for buttons: [UIButton]?) {
        guard let buttons = buttons else { return }
        for button in buttons {
            button.addTarget(self, action: #selector(buttonTapped(_:)), for: .touchUpInside)
            button.tag = buttons.firstIndex(of: button) ?? 0
        }
    }

    @objc func buttonTapped(_ sender: UIButton) {
        if let qOneButtons = qOneButtons, qOneButtons.contains(sender) {
            handleQOneButtonTapped(sender)
        } else if let qTwoButtons = qTwoButtons, qTwoButtons.contains(sender) {
            handleQTwoButtonTapped(sender)
        }
    }
    
    func handleQOneButtonTapped(_ button: UIButton) {
        for btn in qOneButtons {
            if btn == button {
                btn.setImage(UIImage(systemName: "checkmark.circle.fill")?.withTintColor(.orange), for: .normal)
                if let title = btn.titleLabel?.text {
                    answerOneVar = title
                    print("Selected button title: \(title)")
                }
            } else {
                btn.setImage(UIImage(systemName: ""), for: .normal)
                btn.tintColor = .systemBlue
            }
        }
    }
    
    func handleQTwoButtonTapped(_ button: UIButton) {
        for btn in qTwoButtons {
            if btn == button {
                btn.backgroundColor = UIColor(red: 44/255, green: 255/255, blue: 90/255, alpha: 1.0)
                if let title = btn.titleLabel?.text {
                    answerTwoVar = title
                    print("Selected button title: \(title)")
                }
            } else {
                btn.backgroundColor = .white
                // You may want to set other properties for the unselected buttons, e.g., border color, etc.
            }
        }
    }


    @IBAction func backTap(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func submitButton(_ sender: Any) {
        print("answerVar : \(answerVar)")
        print("answerOneVar : \(answerOneVar)")
        print("answerTwoVar : \(answerTwoVar)")
        getApi()
    }
}
extension PatientFeedbackAndResponseVc {
    func getApi() {
        
        let apiURL = APIList().urlString(url:.patientFeedbackResponcesApi)
        let formData : [String : Any] = ["user_id" : patientID,
                        "week" : "",
                        "exercise_completion" : answerVar,
                        "pain_scale" : answerOneVar,
                        "feedback_option" : answerTwoVar,
                        "connection_type" : type,
                        "stability" : stabilityExercises,
                        "mobility" : mobilityExercises,
                        "proprioception" : proprioceptionExercises]
        APIHandler().postAPIValues(type: AddCandidateModel.self, apiUrl: apiURL, method: "POST", formData: formData) {  result in
            switch result {
            case .success(let data):
                DispatchQueue.main.async { [self] in
                    if data.status {
                        showAlert(title: "Success", message: data.message,okActionHandler: {
                            if self.type == "Online"{
                                let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                                let vc = storyBoard.instantiateViewController(withIdentifier: "CandidateHomeVc") as! CandidateHomeVc
                                self.navigationController?.pushViewController(vc, animated: true)
                            }else{
                                let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                                let vc = storyBoard.instantiateViewController(withIdentifier: "Doctors_HomePG") as! Doctors_HomePG
                                self.navigationController?.pushViewController(vc, animated: true)
                            }
                        })
                    } else {
                        showToast(data.message)
                    }
                    stopIndicator()
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async { [self] in
                    stopIndicator()
                    showAlert(title: "Failure", message: "Something Went Wrong", okActionHandler: {})
                }
            }
        }
    }

}
