//
//  PatientInfoPageVc.swift
//  FIEXFIT
//
//  Created by SAIL on 29/02/24.
//

import UIKit

class PatientInfoPageVc: BasicVC {

    var videoData = [videoDetails]()
    var week = ""
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    @IBAction func yesButton(_ sender: Any) {
        
        let vc = self.storyboard!.instantiateViewController(withIdentifier: "ViewVideoVc") as! ViewVideoVc
        vc.videoDetailsData = videoData
        vc.week = week
        self.navigationController?.pushViewController(vc, animated: false)
    }
    @IBAction func noButton(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
}
