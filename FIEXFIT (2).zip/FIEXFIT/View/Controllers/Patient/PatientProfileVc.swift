//
//  PatientProfileVc.swift
//  FIEXFIT
//
//  Created by SAIL on 13/02/24.
//

import UIKit

class PatientProfileVc: BasicVC {
    
    @IBOutlet weak var idView: UIView!
    @IBOutlet weak var nameView: UIView!
    @IBOutlet weak var ageView: UIView!
    @IBOutlet weak var genderView: UIView!
    @IBOutlet weak var idField: UITextField!
    @IBOutlet weak var nameField: UITextField!
    @IBOutlet weak var ageField: UITextField!
    @IBOutlet weak var genderField: UITextField!
    @IBOutlet weak var mobileField: UITextField!
    @IBOutlet weak var profileImage: UIImageView!
    @IBOutlet weak var saveBtn: UIButton!
    
    @IBOutlet weak var patientImage: UIImageView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        idView.layer.cornerRadius = 10
        nameView.layer.cornerRadius = 10
        ageView.layer.cornerRadius = 10
        genderView.layer.cornerRadius = 10
        saveBtn.layer.cornerRadius = 10
   
        patientProfile()
    }
    
    
        
    @IBAction func save(_ sender: Any) {
        
        ProfileUpdate()
        
    }
    
    
    
    @IBAction func backTap(_ sender: Any) {
        
        self.navigationController?.popViewController(animated: false)
    }
    
}
extension PatientProfileVc{
    
    func patientProfile() {
        
        let patientId = UserDefaultsManager.shared.getUserId()
        
            let apiURL = APIList().urlString(url:.PatientProfileAPI)
            
            let formData = ["user_id" : patientId ?? ""]
        
        APIHandler().postAPIValues(type: PatientProfileModel.self, apiUrl: apiURL, method: "POST", formData: formData as [String : Any]) {  result in
                switch result {
                case .success(let data):
                    DispatchQueue.main.async { [self] in
                    if data.status == true{
                        let details = data.patientProfile
                        self.nameField.text = "\(details.patientName)"
                        self.ageField.text = "\(details.dob)"
                        self.genderField.text = "\(details.gender)"
                        self.idField.text = "\(details.userID)"
                        self.mobileField.text = "\(details.mobileNumber)"
                        let imageName = details.photo
                        let imageURL = URL(string: APIList().BASE_URL + imageName)

                        let task = URLSession.shared.dataTask(with: imageURL!) { data, response, error in
                            if let error = error {
                                print("Error loading image: \(error.localizedDescription)")
                                // Set a placeholder image if loading fails
                                DispatchQueue.main.async {
                                    self.patientImage.image = UIImage(named: "Image-8")
                                }
                                return
                            }
                            
                            if let data = data, let image = UIImage(data: data) {
                                // Set the downloaded image on the main thread
                                DispatchQueue.main.async {
                                    self.patientImage.image = image
                                }
                            } else {
                                print("Invalid image data")
                                // Set a placeholder image if loading fails
                                DispatchQueue.main.async {
                                    self.patientImage.image = UIImage(named: "Image-8")
                                }
                            }
                        }
                        task.resume()
                        
                     }
                    else if data.status == false{
                           showToast(data.message )
                        }
                        self.stopIndicator()
                    }
                    case .failure(let error):
                    print(error)
                    DispatchQueue.main.async {
                        self.stopIndicator()
                        self.showAlert(title: "Failure", message: "Something Went Wrong", okActionHandler: {})
                    }
                }
            }
        }
    
    
    func ProfileUpdate() {
        
         let apiURL = APIList().urlString(url:.PatientUpdateProfileAPI)
            
        let formData = [
                        "user_id" : idField.text ?? "",
                        "patient_name" : nameField.text ?? "",
                        "age":ageField.text ?? "",
                        "mobile_number":mobileField.text ?? "",
                        "gender" : genderField.text ?? ""
            ]
        
            APIHandler().postAPIValues(type: AddCandidateModel.self, apiUrl: apiURL, method: "POST", formData: formData) {  result in
                switch result {
                case .success(let data):
                    DispatchQueue.main.async { [self] in
                    if data.status == true{
                        showAlert(title: "Success", message: data.message,okActionHandler: {
                            let vc = self.storyboard?.instantiateViewController(withIdentifier: "CandidateHomeVc") as! CandidateHomeVc
                            self.navigationController?.pushViewController(vc, animated: true)})
                     }
                    else if data.status == false{
                           showToast(data.message )
                    }
                        self.stopIndicator()
                    }
                    case .failure(let error):
                    print(error)
                    DispatchQueue.main.async {
                        self.stopIndicator()
                        self.showAlert(title: "Failure", message: "Something Went Wrong", okActionHandler: {})
                    }
                }
            }
        }

}
