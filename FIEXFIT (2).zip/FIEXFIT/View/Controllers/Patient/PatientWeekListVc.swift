//
//  PatientWeekListVc.swift
//  FIEXFIT
//
//  Created by SAIL on 10/02/24.
//

import UIKit

class PatientWeekListVc: BasicVC {

   

    @IBOutlet weak var weekTable : UITableView!{
        didSet{
            weekTable.delegate = self
            weekTable.dataSource = self
            weekTable.register(UINib.init(nibName: "SessionListTVC", bundle: nil), forCellReuseIdentifier: "SessionListTVC")
        }
    }
    var weekData  = ["Week1", "Week2","Week3","Week4","Week5", "Week6","Week7","Week8"]
    override func viewDidLoad() {
        super.viewDidLoad()
//        getApi()
       
       
    }
    
    @IBAction func backTap(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    

    @IBAction func onBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    
}

extension PatientWeekListVc: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return weekData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SessionListTVC", for: indexPath) as! SessionListTVC
        cell.sessionLbl.text = "\(weekData[indexPath.row])"
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100.0
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let vc = storyboard?.instantiateViewController(withIdentifier: "DailyExercisesVc") as! DailyExercisesVc
        
        vc.weeksData = weekData[indexPath.row]
        navigationController?.pushViewController(vc, animated: true)
    }
}
