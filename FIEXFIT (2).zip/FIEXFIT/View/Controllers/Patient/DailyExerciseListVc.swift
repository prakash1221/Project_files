//
//  DailyExerciseListVc.swift
//  FIEXFIT
//
//  Created by Saranya Ravi on 09/11/23.
//

import UIKit

class DailyExerciseListVc: UIViewController {
    
    @IBOutlet weak var stabilityBtn: UIButton!
    @IBOutlet weak var mobilityBtn: UIButton!
    @IBOutlet weak var propriceptionalBalanceBtn: UIButton!
    @IBOutlet weak var selectionBtn: UIButton!

    var dailySessions = ["Warm Up","Stability","Mobility","Poprioception Balance","Stretches"]
    
   
    override func viewDidLoad() {
        super.viewDidLoad()
        stabilityBtn.layer.cornerRadius = 10
        mobilityBtn.layer.cornerRadius = 10
        propriceptionalBalanceBtn.layer.cornerRadius = 10
        selectionBtn.layer.cornerRadius = 10
        
    }
//    ExerciseListVc
    @IBAction func backTab(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func stabilityBtnAction(_ sender: UIButton) {
      
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "ExerciseListVc") as! ExerciseListVc
        vc.type = "Stability"
        self.navigationController?.pushViewController(vc, animated: true)
    }
    @IBAction func mobilityBtnAction(_ sender: UIButton) {
      
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "ExerciseListVc") as! ExerciseListVc
        vc.type = "Mobility"
        self.navigationController?.pushViewController(vc, animated: true)
    }
    @IBAction func propriceptionalBalanceBtnAction(_ sender: UIButton) {
      
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "ExerciseListVc") as! ExerciseListVc
        vc.type = "Proprioception"
        self.navigationController?.pushViewController(vc, animated: true)
    }
    @IBAction func selectionBtnAction(_ sender: UIButton) {
      
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "AddExercisesVc") as! AddExercisesVc
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
}
