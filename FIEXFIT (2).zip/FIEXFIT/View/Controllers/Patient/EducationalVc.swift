//
//  Educational_Resources.swift
//  FIEXFIT
//
//  Created by SAIL on 31/10/23.
//

import UIKit

class EducationalVc: UIViewController {

//    @IBOutlet weak var pdfImg: UIImageView!
//    @IBOutlet weak var pdfimageWidth: NSLayoutConstraint!
    override func viewDidLoad() {
        super.viewDidLoad()
                
    }
//    override func viewWillAppear(_ animated: Bool) {
//        self.navigationController?.isNavigationBarHidden = true
//    }
//    
    @IBAction func onMoreTips(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "RecoveryTipsVc") as! RecoveryTipsVc
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
   
    @IBAction func onBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
