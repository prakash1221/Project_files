//
//  SampleContainerVc.swift
//  FIEXFIT
//
//  Created by SAIL on 02/11/23.
//

import UIKit

class SampleContainerVc: UIViewController {

    @IBOutlet weak var container1: UIView!
    
    @IBOutlet weak var segment: UISegmentedControl!
    @IBOutlet weak var container2: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()
        container2.isHidden = true
        container1.isHidden = true
        // Do any additional setup after loading the view.
    }
    

    @IBAction func onSegment(_ sender: Any) {
        if segment.selectedSegmentIndex == 0 {
            container2.isHidden = true
            container1.isHidden = false
        }
        else if segment.selectedSegmentIndex == 1 {
            container2.isHidden = false
            container1.isHidden = true
        }
    }
    
}
