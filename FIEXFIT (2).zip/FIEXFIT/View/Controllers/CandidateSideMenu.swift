//
//  CandidateSideMenu.swift
//  FIEXFIT
//
//  Created by SAIL L1 on 20/12/23.
//

import UIKit


protocol SideMenuDelegate {
    func tapAction(index:Int)
}

class CandidateSideMenu: UIViewController {
    
    
    
    @IBOutlet weak var subView: UIView!
    
    
     var delegate: SideMenuDelegate?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        subView.layer.cornerRadius = 10
    }
    

    @IBAction func homeTapped(_ sender: Any) {
        
        self.dismiss(animated: false, completion: nil)
    }
    
    @IBAction func profileTapped(_ sender: Any) {
        
        delegate?.tapAction(index: 0)
        self.dismiss(animated: false, completion: nil)
    }
    
    
    @IBAction func excerciseTapped(_ sender: Any) {
        delegate?.tapAction(index: 1)
        self.dismiss(animated: false, completion: nil)
    }
    
    
    
    @IBAction func progressTapped(_ sender: Any) {
        delegate?.tapAction(index: 2)
        self.dismiss(animated: false, completion: nil)
    }
    
    
    
    @IBAction func educationTapped(_ sender: Any) {
        delegate?.tapAction(index: 3)
        self.dismiss(animated: false, completion: nil)
    }
    
    
    
    @IBAction func discussTapped(_ sender: Any) {
        delegate?.tapAction(index: 4)
        self.dismiss(animated: false, completion: nil)
    }
    
    
    
    @IBAction func logoutTapped(_ sender: Any) {
        delegate?.tapAction(index: 5)
        self.dismiss(animated: false, completion: nil)
    }
    
    
    
    @IBAction func cancelTapped(_ sender: Any) {
        self.dismiss(animated: false, completion: nil)
    }
    
    
    
}
