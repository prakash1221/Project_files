//
//  DropDownVc.swift
//  FIEXFIT
//
//  Created by Saranya Ravi on 09/12/23.
//

import UIKit
protocol dropdownProto {
    func weekResult(Week: String)
    func VideosName(Name : String)
}

class DropDownVc: UIViewController, UITableViewDelegate , UITableViewDataSource {
    
    @IBOutlet weak var bglayoutView: UIView!
    
    @IBOutlet weak var viewHeightLayoutConstrain: NSLayoutConstraint!
    @IBOutlet weak var dropdownTable: UITableView! {
        didSet {
            dropdownTable.delegate = self
            dropdownTable.dataSource = self
        }
    }
    var selectedBtnTag = 0
    var weekList : [String] = ["Week1","Week2","Week3","Week4","Week5","Week6","Week7","Week8"]
    var videoNameList : [String] = ["WarmUp","Stability","Mobility","Proprioception","Stretchers"]

    var selectedItems: [String] = []
    var delegate1 : dropdownProto!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        dropdownTable.register(UINib.init(nibName: "SessionListTVC", bundle: nil), forCellReuseIdentifier: "SessionListTVC")
        bglayoutView.backgroundColor = UIColor.black.withAlphaComponent(0.6)
        dropdownTable.reloadData()
        // Do any additional setup after loading the view.
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        let touch = touches.first
        if touch?.view == self.bglayoutView {
            self.dismiss(animated: true, completion: nil)
        }
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if selectedBtnTag == 1 {
            viewHeightLayoutConstrain.constant = CGFloat(weekList.count * 50) + 10
            return weekList.count
        }else if selectedBtnTag == 2 {
            viewHeightLayoutConstrain.constant = CGFloat(videoNameList.count * 50) + 20
            return videoNameList.count
        }
        
      return 0

    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cell = tableView.dequeueReusableCell(withIdentifier: "SessionListTVC", for: indexPath) as! SessionListTVC
        if selectedBtnTag == 1 {
            cell.sessionLbl.text = weekList[indexPath.row]
            return cell
        }else if selectedBtnTag == 2 {
            cell.sessionLbl.text = videoNameList[indexPath.row]
            return cell
        }
        return cell
        }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if selectedBtnTag == 1 {
            self.delegate1.weekResult(Week: weekList[indexPath.row])
            self.dismiss(animated: true, completion: nil)
        } else if selectedBtnTag == 2 {
            self.delegate1.VideosName(Name: videoNameList[indexPath.row])
            self.dismiss(animated: true, completion: nil)
        }
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50.0
    }

}

