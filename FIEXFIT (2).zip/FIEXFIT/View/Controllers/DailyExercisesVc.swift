//
//  DailyExercisesVc.swift
//  FIEXFIT
//
//  Created by Saranya Ravi on 25/11/23.
//

import UIKit

class DailyExercisesVc: UIViewController {

    var weeksData : String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    
    @IBAction func backTap(_ sender: Any) {
        self.navigationController?.popViewController(animated: false)
    }
    
    @IBAction func warmUpButton(_ sender: UIButton) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "PatientExerciseListVc") as! PatientExerciseListVc
        vc.weeksData = weeksData
        vc.category = "warmUp"
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func stabilityButton(_ sender: UIButton) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "PatientExerciseListVc") as! PatientExerciseListVc
        vc.weeksData = weeksData
        vc.category = "stability"
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func mobilityButton(_ sender: UIButton) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "PatientExerciseListVc") as! PatientExerciseListVc
        vc.weeksData = weeksData
        vc.category = "mobility"
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func proprioceptionButton(_ sender: UIButton) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "PatientExerciseListVc") as! PatientExerciseListVc
        vc.weeksData = weeksData
        vc.category = "proprioception"
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func stretchersButton(_ sender: UIButton) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "PatientExerciseListVc") as! PatientExerciseListVc
        vc.weeksData = weeksData
        vc.category = "stretchers"
        self.navigationController?.pushViewController(vc, animated: true)
    }
   
}
//extension DailyExercisesVc {
//    func getApi() {
//
//        let patientID = UserDefaultsManager.shared.getnamekey() ?? ""
//
//            let apiURL = APIList().urlString(url:.patientVideoDisplay) + patientID + "&week=\(weeksData)&category=\(1)"
//        APIHandler().getAPIValues(type: WeekAndSessionModel.self, apiUrl: apiURL, method: "GET") {  result in
//                switch result {
//                case .success(let data):
//                    DispatchQueue.main.async { [self] in
//                    if data.status == true{
//                        weekData = data.data
//                        weekTable.reloadData()
//                     }
//                    else if data.status == false{
//                           showToast(data.message)
//                        }
//                        self.stopIndicator()
//                    }
//                    case .failure(let error):
//                    print(error)
//                    DispatchQueue.main.async {
//                        self.stopIndicator()
//                        self.showAlert(title: "Failure", message: "Something Went Wrong", okActionHandler: {})
//                    }
//                }
//            }
//        }
//}
