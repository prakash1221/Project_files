package com.example.myapplication;

public class PatientLoginModel {
    private boolean status;
    private String message;
    private Datum[] data;

    // Getters and setters
}
