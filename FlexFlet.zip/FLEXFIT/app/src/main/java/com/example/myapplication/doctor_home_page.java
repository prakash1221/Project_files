package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class doctor_home_page extends AppCompatActivity {

    private Button onlineShiftButton;
    private Button offlineShiftButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_doctor_home_page);

        onlineShiftButton = findViewById(R.id.onlineshift);
        offlineShiftButton = findViewById(R.id.offlineshift);

        onlineShiftButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fetchOnlinePatientList();
            }
        });

        offlineShiftButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fetchOfflinePatientList();
            }
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private void fetchOnlinePatientList() {
        // TODO: Fetch online patient list from the API and display in RecyclerView
        // You can use the PatientList API endpoint here
        // For demonstration, navigate to candidate_list_onn activity
        Intent intent = new Intent(doctor_home_page.this, candidate_list_onn.class);
        startActivity(intent);
    }

    private void fetchOfflinePatientList() {
        // TODO: Fetch offline patient list from the API and display in RecyclerView
        // You can use the PatientList API endpoint here
        // For demonstration, navigate to candidate_list activity
        Intent intent = new Intent(doctor_home_page.this, candidate_list.class);
        startActivity(intent);
    }
}
