package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class login_page extends AppCompatActivity {

    private EditText usernameEditText;
    private EditText passwordEditText;
    private Button doctorButton;
    private Button patientButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_page);

        ImageButton backButton = findViewById(R.id.backbuttonlogin);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent=new Intent(login_page.this, login_type.class);
                startActivity(intent);
            }
        });

        usernameEditText = findViewById(R.id.edit_text_id);
        passwordEditText = findViewById(R.id.edit_text_password);
        patientButton = findViewById(R.id.btn_login);

        doctorButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = usernameEditText.getText().toString().trim();
                String password = passwordEditText.getText().toString().trim();
                if (isValidDoctorLogin(username, password)) {
                    // Doctor login successful, navigate to doctor activity
                    // Replace DoctorActivity.class with your actual Doctor Activity class
                    Toast.makeText(login_page.this, "Doctor login successful", Toast.LENGTH_SHORT).show();
                } else {
                    // Doctor login failed, show error message
                    Toast.makeText(login_page.this, "Invalid doctor credentials", Toast.LENGTH_SHORT).show();
                }
            }
        });

        patientButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = usernameEditText.getText().toString().trim();
                String password = passwordEditText.getText().toString().trim();
                if (isValidPatientLogin(username, password)) {
                    // Patient login successful, navigate to patient activity
                    // Replace PatientActivity.class with your actual Patient Activity class
                    Toast.makeText(login_page.this, "Patient login successful", Toast.LENGTH_SHORT).show();
                } else {
                    // Patient login failed, show error message
                    Toast.makeText(login_page.this, "Invalid patient credentials", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private boolean isValidDoctorLogin(String username, String password) {
        // Add your doctor login validation logic here
        // For demonstration, always return true
        return true;
    }

    private boolean isValidPatientLogin(String username, String password) {
        // Add your patient login validation logic here
        // For demonstration, always return true
        return true;
    }
}
