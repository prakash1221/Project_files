package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.Switch;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class completed_feedback extends AppCompatActivity {
    String response [] = { "Lack of Motivation","Exercises two complicated", "Poor user experience", "Monotony in workouts", "Time constraints", "Health issues", "Technical issues", "Difficultly in understanding exercises through videos"};
    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_completed_feedback);

        ImageButton backButton = findViewById(R.id.image_password);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent=new Intent(completed_feedback.this,daily_exercise_list.class);
                startActivity(intent);
            }
        });

        listView = (ListView) findViewById(R.id.responses);
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>
                (this,R.layout.activity_responses_list, R.id.selectedlest,response);
        listView.setAdapter(arrayAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                Log.i("LIST_VIEW", "Item is clicked @ position"+ position );
            }
        });

        RadioButton radioButtonyes = findViewById(R.id.yes);
        RadioButton radioButtonno = findViewById(R.id.no);

        RadioButton radioButton1 = findViewById(R.id.pain1);
        RadioButton radioButton2 = findViewById(R.id.pain2);
        RadioButton radioButton3 = findViewById(R.id.pain3);
        RadioButton radioButton4 = findViewById(R.id.pain4);
        RadioButton radioButton5 = findViewById(R.id.pain5);
        RadioButton radioButton6 = findViewById(R.id.pain6);
        RadioButton radioButton7 = findViewById(R.id.pain7);
        RadioButton radioButton8 = findViewById(R.id.pain8);
        RadioButton radioButton9 = findViewById(R.id.pain9);
        RadioButton radioButton10 = findViewById(R.id.pain10);

        Button button = findViewById(R.id.btnsave);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String selectedAns = "Nothing selected";
                if(radioButton1.isChecked()){
                    selectedAns = radioButton1.getText().toString();
                } else if(radioButton2.isChecked()){
                    selectedAns = radioButton2.getText().toString();
                } else if(radioButton3.isChecked()){
                    selectedAns = radioButton3.getText().toString();
                } else if(radioButton4.isChecked()){
                    selectedAns = radioButton4.getText().toString();
                } else if(radioButton5.isChecked()){
                    selectedAns = radioButton5.getText().toString();
                } else if(radioButton5.isChecked()){
                    selectedAns = radioButton5.getText().toString();
                } else if(radioButton6.isChecked()){
                    selectedAns = radioButton6.getText().toString();
                } else if(radioButton7.isChecked()){
                    selectedAns = radioButton7.getText().toString();
                } else if(radioButton8.isChecked()){
                    selectedAns = radioButton8.getText().toString();
                } else if(radioButton9.isChecked()){
                    selectedAns = radioButton9.getText().toString();
                } else if(radioButton10.isChecked()){
                    selectedAns = radioButton10.getText().toString();
                }
            }
        });

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String selectoption = "Nothing seleccted";
                if (radioButtonyes.isChecked()){
                    selectoption = radioButtonyes.getText().toString();
                } else if(radioButtonno.isChecked()){
                    selectoption = radioButtonno.getText().toString();
                }
            }
        });


        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_completed_feedback);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

}