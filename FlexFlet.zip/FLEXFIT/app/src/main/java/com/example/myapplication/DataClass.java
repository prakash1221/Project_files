package com.example.myapplication;


public class DataClass {
    private String username;
    private String doctorID;
    private String password;
    private String name;
    private String age;
    private String gender;

    // Getters and setters
}

