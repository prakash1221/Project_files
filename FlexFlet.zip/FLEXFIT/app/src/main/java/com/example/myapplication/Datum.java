package com.example.myapplication;

public class Datum {
    private String patID;
    private String userID;
    private String password;
    private String patientName;
    private String dob;
    private String age;
    private String gender;
    private String fmsScore;
    private String mobileNumber;
    private String connectionType;

    // Getters and setters
}
