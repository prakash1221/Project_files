package com.example.myapplication;

public class DoctorLoginDetail {
    private String username;
    private String doctorID;
    private String name;
    private String age;
    private String gender;

    // Getters and setters
}
