package com.example.myapplication;

public class DoctorLoginModel {
    private boolean status;
    private String message;
    private DoctorLoginDetail[] data;

    // Getters and setters
}
