package com.example.myapplication;

public class API {

    private static final String BASE_URL = "http://localhost/flexfit/";


        public static final String PatientLoginAPI = BASE_URL + ("patient_login.php");
        public static final String DoctorLoginAPI = BASE_URL + ("login_page.php");
        public static final String PatientList = BASE_URL + ("show_patient_list.php");
        public static final String PatientProfileAPI = BASE_URL + ("patient_profile.php");
        public static final String PatientUpdateProfileAPI = BASE_URL + ("patient_updateprofile.php");
        public static final String AddPatientAPI = BASE_URL + ("add_patient.php");
        public static final String DoctorProfile = BASE_URL + ("doctor_profile.php");
        public static final String DoctorUpdateProfile = BASE_URL + ("doctor_updateprofile.php");
        public static final String WeekAndSessionAPI = BASE_URL + ("weeks_sessions.php?user_id=");
        public static final String DisplaySessionAPI = BASE_URL + ("display_sessions.php?category=");
        public static final String SelectTitleAPI = BASE_URL + ("select_titles.php?category");
        public static final String PatientVideoDisplay = BASE_URL + ("patient_videos_display.php?user_id=");
        public static final String OnlinePatientListGraphAPI = BASE_URL + ("online_patientlist_graph.php?");
        public static final String OfflinePatientListGraphAPI = BASE_URL + ("offline_patientlist_graph.php?");
        public static final String PatientGraphAPI = BASE_URL + ("patient_graph.php?user_id=");
        public static final String AddVideoAPI = BASE_URL + ("add_exercises.php");
        public static final String PatientVideoListAPI = BASE_URL + ("patient_video_list.php");
        public static final String PatientFeedbackResponsesAPI = BASE_URL + ("feedback_responses.php");
        public static final String FetchFeedbackResponsesAPI = BASE_URL + ("fetch_the_responses.php");
        public static final String SavedVideosAPI = BASE_URL + ("saved_videos.php");
        public static final String PatientRecordedVideo = BASE_URL + ("patient_recorded_videos.php");
        public static final String DisplayVideoTitleAPI = BASE_URL + ("display_video_titles.php?category=");


}
