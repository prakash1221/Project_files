package com.example.myapplication;

public class DoctorProfile {
    private boolean success;
    private DataClass data;
    private String message;

    // Getters and setters
}
