package com.example.myapplication;

import static com.example.myapplication.API.DoctorLoginAPI;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.HashMap;
import java.util.Map;

public class doctor_login extends AppCompatActivity {

    private EditText docIDTxt, docPasswordTxt;
    private ImageButton eyeimagebutton;
    private RequestQueue requestQueue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_login);

        ImageButton backButton = findViewById(R.id.backbuttonweek);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent=new Intent(doctor_login.this,login_type.class);
                startActivity(intent);
            }
        });

        docIDTxt = findViewById(R.id.edit_text_id);
        docPasswordTxt = findViewById(R.id.edit_text_password);
        eyeimagebutton = findViewById(R.id.btn_toggle_password);

        requestQueue = Volley.newRequestQueue(this);

        eyeimagebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                togglePasswordVisibility();
            }
        });
    }

    private void togglePasswordVisibility() {
        // Toggle password visibility logic
    }

    public void onDocLoginClick(View view) {
        String doctorID = docIDTxt.getText().toString();
        String password = docPasswordTxt.getText().toString();

        if (doctorID.isEmpty()) {
            showToast("Enter the ID");
        } else if (password.isEmpty()) {
            showToast("Enter the Password");
        } else {
            postAPI(doctorID, password);
        }
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    private void postAPI(String doctorID, String password) {
        String url = DoctorLoginAPI;

        Map<String, String> formData = new HashMap<>();
        formData.put("doctor_id", doctorID);
        formData.put("password", password);

        JSONObject jsonBody = new JSONObject(formData);

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, url, jsonBody,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            boolean status = response.getBoolean("status");
                            if (status) {
                                showToast("Login successful");
                                // Proceed to next activity
                                Intent intent = new Intent(doctor_login.this, doctor_home_page.class);
                                startActivity(intent);
                                finish(); // Prevent returning to this activity on back press
                            } else {
                                String message = response.getString("message");
                                showToast("Login failed: " + message);
                            }
                        } catch (JSONException e) {
                            showToast("Error parsing response");
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                showToast("Failed to login: " + error.getMessage());
            }
        });

        requestQueue.add(request);
    }
}
