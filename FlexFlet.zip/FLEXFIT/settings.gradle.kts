// pluginManagement block
pluginManagement {
    repositories {
        google()
        gradlePluginPortal()
    }
}

// dependencyResolutionManagement block
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

// Project configuration
rootProject.name = "My Application"
include(":app")
